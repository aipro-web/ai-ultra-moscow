# AI Ultra Drive → GitHub Sync

Target repository: `aipro-web/ai-ultra-moscow`

Source Google Drive folder:
`AI ULTRA / GITHUB-INBOX`

Current folder ID:
`1YWFgkPj5Hbf7mzcDmsRCo19DHSqW4ow7`

Expected source folders:
- `SEO`
- `CAROUSEL`

## What the workflow does

Every 5 minutes (and manually on demand):
1. Reads `GITHUB-INBOX` from Google Drive.
2. Verifies `SEO` and `CAROUSEL` exist.
3. Safely extracts every ZIP into a folder named after the ZIP.
4. Copies non-ZIP files as-is.
5. Writes a SHA-256 manifest.
6. Commits only to branch `drive-sync`.
7. Never auto-merges into `main`.

## One-time setup

### 1. Seed these files in the repository
Copy:
- `.github/workflows/drive-sync.yml`
- `scripts/materialize_drive_inbox.py`

Commit them to the default branch (`main`).

### 2. Create a Google Cloud service account
Create a service account such as:
`github-drive-sync`

Create a JSON key for it.

### 3. Share Drive folder with service account
Share the `GITHUB-INBOX` folder with the service account email as **Viewer**.

### 4. Add GitHub Actions secrets
Repository → Settings → Secrets and variables → Actions → New repository secret

Add:
- `GDRIVE_FOLDER_ID` = `1YWFgkPj5Hbf7mzcDmsRCo19DHSqW4ow7`
- `GDRIVE_SERVICE_ACCOUNT_JSON` = full contents of the downloaded service-account JSON key

### 5. GitHub Actions write permission
Repository → Settings → Actions → General → Workflow permissions
Select:
`Read and write permissions`

Save.

### 6. First test
Actions → `Drive Sync` → `Run workflow`

Expected result:
- branch `drive-sync` is created;
- `drive-inbox/SEO/...` appears;
- `drive-inbox/CAROUSEL/...` appears;
- `_manifest.json` appears.

## Safety rules

- `main` is never modified by this sync workflow.
- Empty/broken Drive reads fail before deletion/push.
- ZIP path traversal is blocked.
- Secrets are never committed.
