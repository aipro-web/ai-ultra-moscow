#!/usr/bin/env python3
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_extract(zf: zipfile.ZipFile, dest: Path) -> None:
    base = dest.resolve()
    for member in zf.infolist():
        target = (dest / member.filename).resolve()
        if target != base and base not in target.parents:
            raise RuntimeError(f"Unsafe ZIP path: {member.filename}")
    zf.extractall(dest)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: materialize_drive_inbox.py <source> <dest>")

    source = Path(sys.argv[1]).resolve()
    dest = Path(sys.argv[2]).resolve()

    if not source.is_dir():
        raise SystemExit(f"Source folder missing: {source}")

    required = [source / "SEO", source / "CAROUSEL"]
    for path in required:
        if not path.is_dir():
            raise SystemExit(f"Required folder missing: {path}")

    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    manifest = []

    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue

        rel = path.relative_to(source)
        record = {
            "source": rel.as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256(path),
        }

        if path.suffix.lower() == ".zip":
            out = dest / rel.with_suffix("")
            out.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(path) as zf:
                safe_extract(zf, out)
            record["mode"] = "unzipped"
            record["target"] = out.relative_to(dest).as_posix()
        else:
            out = dest / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, out)
            record["mode"] = "copied"
            record["target"] = out.relative_to(dest).as_posix()

        manifest.append(record)

    (dest / "_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
