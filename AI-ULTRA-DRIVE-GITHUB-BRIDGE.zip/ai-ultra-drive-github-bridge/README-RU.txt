AI ULTRA — GOOGLE DRIVE -> GITHUB BRIDGE

Что делает:
- Читает Google Drive папку AI ULTRA/GITHUB-INBOX.
- Синхронизирует новые/изменённые файлы в GitHub repo aipro-web/ai-ultra-moscow.
- Пишет только в ветку drive-sync.
- main не трогает.
- Запускается автоматически раз в 5 минут.
- Не требует подключения GitHub к ChatGPT.

Требуется один раз:
1) GitHub Fine-grained PAT с доступом только к ai-ultra-moscow и Repository permissions -> Contents: Read and write.
2) Новый проект Google Apps Script.
3) Вставить Code.gs.
4) В Project Settings -> Script properties добавить:
   GITHUB_TOKEN = ваш токен
   REPO_OWNER = aipro-web
   REPO_NAME = ai-ultra-moscow
   DRIVE_FOLDER_ID = 1YWFgkPj5Hbf7mzcDmsRCo19DHSqW4ow7
   BRANCH = drive-sync
5) Запустить testConnection() один раз и выдать разрешения Google.
6) Запустить setup() один раз.

После этого синхронизация работает автоматически каждые 5 минут.

ВАЖНО:
- Токен не хранить в Code.gs. Только Script Properties.
- Для токена выбирайте доступ только к одному репозиторию ai-ultra-moscow.
- main намеренно не используется: сначала проверяем drive-sync.
