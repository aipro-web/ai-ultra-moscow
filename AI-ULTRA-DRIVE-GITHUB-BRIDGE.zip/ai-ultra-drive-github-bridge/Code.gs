/**
 * AI Ultra Drive -> GitHub bridge
 * Source: Google Drive GITHUB-INBOX folder
 * Destination: GitHub branch drive-sync
 *
 * Required Script Property:
 * GITHUB_TOKEN
 * Optional (defaults already set):
 * REPO_OWNER, REPO_NAME, DRIVE_FOLDER_ID, BRANCH
 */

const API = 'https://api.github.com';
const DEFAULTS = {
  owner: 'aipro-web',
  repo: 'ai-ultra-moscow',
  driveFolderId: '1YWFgkPj5Hbf7mzcDmsRCo19DHSqW4ow7',
  branch: 'drive-sync',
  repoPrefix: 'drive-inbox'
};

function setup() {
  validateConfig_();
  removeSyncTriggers_();
  ScriptApp.newTrigger('syncDriveToGitHub')
    .timeBased()
    .everyMinutes(5)
    .create();
  const result = syncDriveToGitHub();
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function testConnection() {
  const cfg = getConfig_();
  validateConfig_();
  const me = github_(cfg, 'GET', '/user');
  const repo = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}`);
  const folder = DriveApp.getFolderById(cfg.driveFolderId);
  const out = {
    ok: true,
    githubLogin: me.login,
    repository: repo.full_name,
    driveFolder: folder.getName(),
    targetBranch: cfg.branch
  };
  Logger.log(JSON.stringify(out, null, 2));
  return out;
}

function syncDriveToGitHub() {
  const cfg = getConfig_();
  validateConfig_();

  const source = DriveApp.getFolderById(cfg.driveFolderId);
  const files = collectFiles_(source, cfg.repoPrefix);
  if (!files.length) {
    return { ok: true, changed: false, message: 'GITHUB-INBOX is empty' };
  }

  let targetHead = getBranchHead_(cfg, cfg.branch);
  const state = loadState_();

  // If drive-sync does not exist yet, upload everything on first run.
  const changed = targetHead
    ? files.filter(f => state[f.driveId] !== f.fingerprint)
    : files;

  if (!changed.length) {
    return { ok: true, changed: false, scanned: files.length, message: 'No Drive changes' };
  }

  // Empty GitHub repos cannot accept a new secondary ref directly.
  // Bootstrap the repository once on its default branch, then create drive-sync from it.
  const baseHead = targetHead || ensureBaseHead_(cfg);

  const treeItems = changed.map(f => {
    const blobSha = createBlob_(cfg, f.bytes);
    return { path: f.path, mode: '100644', type: 'blob', sha: blobSha };
  });

  const treeSha = createTree_(cfg, treeItems, baseHead.treeSha);
  const commitSha = createCommit_(
    cfg,
    treeSha,
    [baseHead.commitSha],
    `sync(drive): ${changed.length} file(s) from GITHUB-INBOX`
  );

  if (targetHead) {
    updateBranchRef_(cfg, cfg.branch, commitSha);
  } else {
    createBranchRef_(cfg, cfg.branch, commitSha);
  }

  changed.forEach(f => state[f.driveId] = f.fingerprint);
  saveState_(state);

  return {
    ok: true,
    changed: true,
    scanned: files.length,
    uploaded: changed.length,
    branch: cfg.branch,
    commit: commitSha
  };
}

function resetSyncState() {
  PropertiesService.getScriptProperties().deleteProperty('SYNC_STATE');
  return 'SYNC_STATE cleared';
}

function removeSyncTriggers_() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'syncDriveToGitHub') ScriptApp.deleteTrigger(t);
  });
}

function getConfig_() {
  const p = PropertiesService.getScriptProperties();
  return {
    token: p.getProperty('GITHUB_TOKEN'),
    owner: p.getProperty('REPO_OWNER') || DEFAULTS.owner,
    repo: p.getProperty('REPO_NAME') || DEFAULTS.repo,
    driveFolderId: p.getProperty('DRIVE_FOLDER_ID') || DEFAULTS.driveFolderId,
    branch: p.getProperty('BRANCH') || DEFAULTS.branch,
    repoPrefix: DEFAULTS.repoPrefix
  };
}

function validateConfig_() {
  const cfg = getConfig_();
  if (!cfg.token) throw new Error('Missing Script Property: GITHUB_TOKEN');
  DriveApp.getFolderById(cfg.driveFolderId).getName();
  return true;
}

function collectFiles_(folder, prefix) {
  const out = [];
  walkFolder_(folder, prefix, out);
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

function walkFolder_(folder, prefix, out) {
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    const name = sanitizePathPart_(f.getName());

    // Do not sync the bridge packages themselves.
    if (
      name === 'AI-ULTRA-DRIVE-GITHUB-BRIDGE.zip' ||
      name === 'AI-ULTRA-DRIVE-SYNC-WORKFLOW.zip' ||
      name === 'Code.gs'
    ) continue;

    const blob = f.getBlob();
    const bytes = blob.getBytes();
    const updated = f.getLastUpdated().getTime();
    out.push({
      driveId: f.getId(),
      path: `${prefix}/${name}`,
      bytes,
      fingerprint: `${updated}:${bytes.length}:${f.getName()}`
    });
  }

  const folders = folder.getFolders();
  while (folders.hasNext()) {
    const child = folders.next();
    walkFolder_(child, `${prefix}/${sanitizePathPart_(child.getName())}`, out);
  }
}

function sanitizePathPart_(s) {
  return String(s).replace(/[\\]/g, '-').replace(/^\.+$/, '_').trim();
}

function ensureBaseHead_(cfg) {
  const repo = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}`);
  const baseBranch = repo.default_branch || 'main';
  let head = getBranchHead_(cfg, baseBranch);
  if (head) return head;

  // One-time harmless bootstrap for a completely empty repository.
  // This creates only a tiny marker on the default branch; project files stay in drive-sync.
  const content = Utilities.base64Encode(
    Utilities.newBlob('AI Ultra repository bootstrap. Project sync lives in branch drive-sync.\n').getBytes()
  );

  github_(cfg, 'PUT', `/repos/${cfg.owner}/${cfg.repo}/contents/.ai-ultra-bootstrap.md`, {
    message: 'chore: bootstrap repository for Drive sync',
    content: content
  });

  head = getBranchHead_(cfg, baseBranch);
  if (!head) throw new Error(`Could not bootstrap default branch: ${baseBranch}`);
  return head;
}

function getBranchHead_(cfg, branchName) {
  try {
    const ref = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/ref/heads/${encodeURIComponent(branchName)}`);
    const commit = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/commits/${ref.object.sha}`);
    return { commitSha: ref.object.sha, treeSha: commit.tree.sha };
  } catch (e) {
    const s = String(e);
    if (s.includes('GitHub 404') || s.includes('GitHub 409')) return null;
    throw e;
  }
}

function createBlob_(cfg, bytes) {
  const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/blobs`, {
    content: Utilities.base64Encode(bytes),
    encoding: 'base64'
  });
  return r.sha;
}

function createTree_(cfg, items, baseTreeSha) {
  const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/trees`, {
    base_tree: baseTreeSha,
    tree: items
  });
  return r.sha;
}

function createCommit_(cfg, treeSha, parents, message) {
  const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/commits`, {
    message: message,
    tree: treeSha,
    parents: parents
  });
  return r.sha;
}

function createBranchRef_(cfg, branchName, commitSha) {
  github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/refs`, {
    ref: `refs/heads/${branchName}`,
    sha: commitSha
  });
}

function updateBranchRef_(cfg, branchName, commitSha) {
  github_(cfg, 'PATCH', `/repos/${cfg.owner}/${cfg.repo}/git/refs/heads/${encodeURIComponent(branchName)}`, {
    sha: commitSha,
    force: false
  });
}

function github_(cfg, method, path, body) {
  const options = {
    method: method,
    muteHttpExceptions: true,
    headers: {
      Authorization: `Bearer ${cfg.token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28'
    }
  };

  if (body !== undefined) {
    options.contentType = 'application/json';
    options.payload = JSON.stringify(body);
  }

  const res = UrlFetchApp.fetch(API + path, options);
  const code = res.getResponseCode();
  const text = res.getContentText();
  let json = {};
  try { json = text ? JSON.parse(text) : {}; } catch (_) { json = { raw: text }; }

  if (code < 200 || code >= 300) {
    throw new Error(`GitHub ${code}: ${json.message || text}`);
  }
  return json;
}

function loadState_() {
  const raw = PropertiesService.getScriptProperties().getProperty('SYNC_STATE');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch (_) { return {}; }
}

function saveState_(state) {
  PropertiesService.getScriptProperties().setProperty('SYNC_STATE', JSON.stringify(state));
}
