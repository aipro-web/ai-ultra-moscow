# V31 motion patch

Restored native-flow scroll from Pass 4 V20/V21. Static checks are run after generation.

# AI ULTRA SEO Carousel V30 — QA

## Architecture
- Base: AI-ULTRA-PASS4-MASTER-V29-QUEUED-STEPS-CTA-ALL.
- Motion core preserved; one accepted manual impulse still advances one adjacent card.
- Front-side content only; hero flip disabled.
- Desktop starts with 5 visible content cards; mobile starts with 1.
- 500-step geometric/path flow preserved independently from page content count.
- Page content cycles by each page's 6–7 semantic chapters.

## SEO checks
- 12 indexable routes.
- Exactly one H1 per route.
- Unique title and meta description per route.
- robots=index,follow on all routes.
- canonical present on all routes.
- Organization + WebSite + Service JSON-LD present.
- Same semantic HTML content is projected visibly onto 3D glass cards; no separate hidden keyword layer was added.
- Crawlable internal service links are present inside the final content card of each route.
- robots.txt included.
- sitemap.template.xml included; final production hostname intentionally not invented. Replace {SITE_URL} when the domain is fixed.

## Static QA
- All 12 module scripts pass `node --check`.
- All semantic manifests parse as valid JSON.
- Article count matches manifest card count on every route.
- All relative internal links resolve to existing local pages.
- Title length <= 65 chars; descriptions <= 180 chars.

## Runtime note
- The inherited V29 scene loads Three.js, GSAP and path4.json from external CDNs/GitHub. The current isolated build environment has no outbound DNS, so full WebGL screenshot/FPS rendering could not be executed here. No dependency URLs or scene mathematics were changed in V30.
