# AI ULTRA SEO CAROUSEL V31 — FAST NATIVE FLOW

V31 restores the original continuous Pass 4 scroll physics from V20/V21 while preserving V30 SEO/content architecture.

- No one-wheel-event/one-card gate.
- Wheel delta directly moves the camera along the curved card stream.
- A strong wheel roll can sweep through dozens of background cards.
- Final destination snaps to the nearest content card only after input ends.
- SEO/card copy and CTA are hidden during high-speed travel and reappear after settle.
- Desktop keeps the five-card composition at rest.
- All V30 intent URLs and metadata are preserved.

# AI ULTRA SEO Carousel V30

- Based on V29 queued-step carousel.
- Front-side content only. Hero flip disabled.
- Desktop starts with 5 content cards visible; mobile starts with 1 for readability/performance.
- One route = one search intent.
- Semantic HTML articles are the same visible content projected onto the glass cards.
- 500-step geometric flow preserved; content cycles independently by the page card count.
- Production: replace `{SITE_URL}` in sitemap.template.xml and rename to sitemap.xml after the final domain is known.
