# SEO route map

| Priority | Route | Intent |
|---|---|---|
| P0 | `/voice-ai/` | Voice AI для бизнеса |
| P0 | `/ai-sales-agent/` | AI-агент продаж |
| P0 | `/ai-crm/` | AI интеграция с CRM |
| P0 | `/ai-automation/` | AI автоматизация бизнеса |
| P0 | `/corporate-ai/` | корпоративный AI и RAG |
| P0 | `/enterprise-ai/` | enterprise AI multi-agent |
| P0 | `/ai-employees/` | AI сотрудники для бизнеса |
| P0 | `/seo-geo/` | SEO и GEO продвижение |
| P1 | `/ai-chatbots/` | AI чат-бот для бизнеса |
| P1 | `/crm-automation/` | автоматизация CRM |
| P0 showcase | `/3d-web-development/` | разработка 3D сайтов WebGL |
| Brand/core | `/` | AI-решения и автоматизация бизнеса |

Rule: one route = one materially distinct search intent. Cards are chapters of the route, not separate SEO pages.
