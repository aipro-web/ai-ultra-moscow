v1.5.9.31 EXACT CARDSONLY LED

ONLY CHANGE:
- Main carousel physical LED contour is now the exact Cards Only 2px conic-gradient palette and angle mapping, rendered as a real rounded mesh band on all cards.
- Existing main-carousel emitted bloom/light is unchanged.
- No carousel physics, content, layout, raster, buttons, labels, scroll, or Route Travel changes.
