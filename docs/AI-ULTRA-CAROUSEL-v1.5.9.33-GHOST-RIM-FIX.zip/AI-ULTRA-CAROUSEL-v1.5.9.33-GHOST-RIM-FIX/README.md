AI ULTRA v1.5.9.33 — GHOST-RIM-FIX

ONLY CHANGE:
- Removed ghost WebGL glow outlines from recycled/non-displayed card slots during scroll.
- Native glow remains unchanged on the cards that are actually displayed.

UNCHANGED:
- Cards Only LED contour
- Content, card sizes/positions, raster, buttons
- Scroll/drag physics and Route Travel
