AI ULTRA v1.5.9.34 — HERO TEXT CONTINUITY

ONLY CHANGES:
- Card 01 H1 is never line-clamped/ellipsized by CSS.
- Card 01 lead: 'Внедряем ИИ/AI-Решения под ключ: автоматизируем любые…'
- Card 02 visibly continues: '…бизнес-процессы. Заряжаем продажи и подключаем CRM.'
- Card 02 centered state expands that continuation into the full ecosystem text.

UNCHANGED:
- LED contour, native carousel bloom, raster, card geometry
- buttons, scroll/drag physics, Route Travel
