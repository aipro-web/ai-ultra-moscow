AI Ultra v1.5.9.32 — VISIBLE CARDSONLY LED

Strict change only:
- Main carousel visible DOM card surface gets the exact Cards Only conic-gradient LED contour.
- Original carousel WebGL edgeGlow/bloom/light emission is untouched.
- Previous hidden WebGL gradient band is disabled to prevent double-outline artifacts.
- No content, card layout, raster, physics, scrolling, Route Travel, or buttons changed.
