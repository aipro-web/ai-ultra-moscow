v1.5.9.30
- Main carousel card perimeter now uses the exact Cards Only gold/pearl conic gradient as a separate non-bloom outline.
- Original main-scene bloom/emitted light material and intensity restored and preserved.
- live.html is a permanent bookmark URL that cache-busts the root carousel automatically.
- Carousel physics/content/Route Travel untouched.
