AI ULTRA v1.5.9.35 — MOBILE GHOST CLEANUP

Only change: mobile keeps one active card at rest and at most current+incoming during swipe; recycled mobile card slots are immediately hidden. Desktop composition, LED contour, native bloom, content, physics and Route Travel unchanged.
