AI ULTRA v1.5.9.34 — SCROLL-GHOST-CLEANUP

ONLY CHANGE:
- Native WebGL glow rims now respect each card's own stack order.
- During active scrolling, distant/recycling glow rims are hidden so old-card outlines do not remain on screen.
- At rest the native carousel glow returns normally.

UNCHANGED:
- Cards Only LED contour
- Native glow material/intensity
- Content, raster, buttons, card positions
- Scroll/drag physics and Route Travel
