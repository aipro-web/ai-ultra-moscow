/**
 * AI Ultra Drive -> GitHub bridge V2
 *
 * Drive GITHUB-INBOX is the source of truth.
 * - Every file is mirrored to branch drive-sync under drive-inbox/.
 * - The newest ZIP inside SEO/ is unpacked to workspace/seo/current/.
 * - The newest ZIP inside CAROUSEL/ is unpacked to workspace/carousel/current/.
 * - When a CURRENT ZIP changes, stale extracted files are removed.
 *
 * Required Script Property:
 *   GITHUB_TOKEN
 * Optional (defaults already set):
 *   REPO_OWNER, REPO_NAME, DRIVE_FOLDER_ID, BRANCH
 */

const API = 'https://api.github.com';
const BRIDGE_VERSION = '2.1.0';
const BLOB_BATCH_SIZE = 12;
const DEFAULTS = {
  owner: 'aipro-web',
  repo: 'ai-ultra-moscow',
  driveFolderId: '1YWFgkPj5Hbf7mzcDmsRCo19DHSqW4ow7',
  branch: 'drive-sync',
  repoPrefix: 'drive-inbox',
  workspacePrefix: 'workspace'
};

function setup() {
  validateConfig_();
  removeSyncTriggers_();
  ScriptApp.newTrigger('syncDriveToGitHub')
    .timeBased()
    .everyMinutes(5)
    .create();

  // Force one CURRENT workspace rebuild after installing/updating bridge code.
  const result = syncDriveToGitHub(true);
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function testConnection() {
  const cfg = getConfig_();
  validateConfig_();
  const me = github_(cfg, 'GET', '/user');
  const repo = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}`);
  const folder = DriveApp.getFolderById(cfg.driveFolderId);
  const out = {
    ok: true,
    bridgeVersion: BRIDGE_VERSION,
    githubLogin: me.login,
    repository: repo.full_name,
    driveFolder: folder.getName(),
    targetBranch: cfg.branch,
    workspace: `${cfg.workspacePrefix}/{seo,carousel}/current`
  };
  Logger.log(JSON.stringify(out, null, 2));
  return out;
}

function syncDriveToGitHub(forceWorkspace) {
  forceWorkspace = forceWorkspace === true;

  const cfg = getConfig_();
  validateConfig_();

  const source = DriveApp.getFolderById(cfg.driveFolderId);
  const files = collectFiles_(source, cfg.repoPrefix);
  if (!files.length) {
    return { ok: true, changed: false, message: 'GITHUB-INBOX is empty' };
  }

  const targetHead = getBranchHead_(cfg, cfg.branch);
  const baseHead = targetHead || ensureBaseHead_(cfg);

  const rawState = loadJsonProperty_('SYNC_STATE');
  const workspaceState = loadJsonProperty_('WORKSPACE_STATE');

  // Mirror changed raw Drive files, but do not re-upload all archives on a bridge-code update.
  const changedRaw = targetHead
    ? files.filter(f => rawState[f.driveId] !== f.fingerprint)
    : files;

  const workspacePlan = buildWorkspacePlan_(cfg, files, workspaceState, forceWorkspace);

  if (!changedRaw.length && !workspacePlan.changed) {
    return {
      ok: true,
      changed: false,
      scanned: files.length,
      message: 'No Drive or CURRENT workspace changes'
    };
  }

  const addEntries = [];

  // 1) Raw mirror blobs.
  changedRaw.forEach(f => {
    addEntries.push({ path: f.path, bytes: f.bytes });
  });

  // 2) CURRENT extracted workspace blobs.
  workspacePlan.files.forEach(f => {
    addEntries.push({ path: f.path, bytes: f.bytes });
  });

  // 3) Deterministic workspace manifest.
  if (workspacePlan.changed) {
    const manifest = {
      bridgeVersion: BRIDGE_VERSION,
      branch: cfg.branch,
      sourceFolder: 'GITHUB-INBOX',
      current: workspacePlan.manifest
    };
    addEntries.push({
      path: `${cfg.workspacePrefix}/_CURRENT.json`,
      bytes: Utilities.newBlob(JSON.stringify(manifest, null, 2) + '\n').getBytes()
    });
  }

  // Create Git blobs in small parallel batches. This is much faster than
  // one HTTP request per file and avoids Apps Script timeouts on first import.
  const blobShas = createBlobsBatch_(cfg, addEntries);
  const treeAdds = addEntries.map((f, i) => ({
    path: f.path,
    mode: '100644',
    type: 'blob',
    sha: blobShas[i]
  }));

  // Remove stale CURRENT files that are no longer present in the newest ZIP(s).
  let treeDeletes = [];
  if (workspacePlan.changed && targetHead) {
    const refreshPrefixes = workspacePlan.refreshPrefixes;
    const existing = getTreeBlobPaths_(cfg, baseHead.treeSha)
      .filter(path => refreshPrefixes.some(prefix => path === prefix || path.indexOf(prefix + '/') === 0));

    const newPaths = {};
    treeAdds.forEach(e => { newPaths[e.path] = true; });

    treeDeletes = existing
      .filter(path => !newPaths[path])
      .map(path => ({ path: path, mode: '100644', type: 'blob', sha: null }));
  }

  const treeItems = treeDeletes.concat(treeAdds);
  const treeSha = createTree_(cfg, treeItems, baseHead.treeSha);

  const commitParts = [];
  if (changedRaw.length) commitParts.push(`${changedRaw.length} Drive file(s)`);
  if (workspacePlan.changed) commitParts.push('refresh CURRENT workspace');

  const commitSha = createCommit_(
    cfg,
    treeSha,
    [baseHead.commitSha],
    `sync(drive): ${commitParts.join(' + ')}`
  );

  if (targetHead) {
    updateBranchRef_(cfg, cfg.branch, commitSha);
  } else {
    createBranchRef_(cfg, cfg.branch, commitSha);
  }

  changedRaw.forEach(f => { rawState[f.driveId] = f.fingerprint; });
  saveJsonProperty_('SYNC_STATE', rawState);

  Object.keys(workspacePlan.nextState).forEach(k => {
    workspaceState[k] = workspacePlan.nextState[k];
  });
  saveJsonProperty_('WORKSPACE_STATE', workspaceState);

  return {
    ok: true,
    changed: true,
    bridgeVersion: BRIDGE_VERSION,
    scanned: files.length,
    rawUploaded: changedRaw.length,
    workspaceFilesUploaded: workspacePlan.files.length,
    workspaceSources: workspacePlan.manifest,
    deletedStaleWorkspaceFiles: treeDeletes.length,
    branch: cfg.branch,
    commit: commitSha
  };
}

function buildWorkspacePlan_(cfg, files, workspaceState, forceWorkspace) {
  const categories = [
    { drive: 'SEO', key: 'seo' },
    { drive: 'CAROUSEL', key: 'carousel' }
  ];

  const out = {
    changed: false,
    files: [],
    manifest: {},
    nextState: {},
    refreshPrefixes: []
  };

  categories.forEach(cat => {
    const latest = selectLatestZip_(files, cfg.repoPrefix, cat.drive);
    if (!latest) {
      out.manifest[cat.key] = null;
      return;
    }

    out.manifest[cat.key] = {
      archive: latest.name,
      driveId: latest.driveId,
      modifiedMs: latest.updated,
      fingerprint: latest.fingerprint
    };

    const needsRefresh = forceWorkspace || workspaceState[cat.key] !== latest.fingerprint;
    if (!needsRefresh) return;

    out.changed = true;
    out.nextState[cat.key] = latest.fingerprint;

    const dest = `${cfg.workspacePrefix}/${cat.key}/current`;
    out.refreshPrefixes.push(dest);

    const extracted = unzipToRepoFiles_(latest, dest);
    extracted.forEach(f => out.files.push(f));

    const sourceInfo = {
      sourceArchive: latest.name,
      sourceDriveId: latest.driveId,
      sourceModifiedMs: latest.updated,
      fingerprint: latest.fingerprint,
      extractedFiles: extracted.length,
      bridgeVersion: BRIDGE_VERSION
    };
    out.files.push({
      path: `${dest}/_AI_ULTRA_SOURCE.json`,
      bytes: Utilities.newBlob(JSON.stringify(sourceInfo, null, 2) + '\n').getBytes()
    });
  });

  if (out.changed) out.refreshPrefixes.push(`${cfg.workspacePrefix}/_CURRENT.json`);
  return out;
}

function selectLatestZip_(files, repoPrefix, topFolder) {
  const prefix = `${repoPrefix}/${topFolder}/`;
  const candidates = files.filter(f =>
    f.path.indexOf(prefix) === 0 && /\.zip$/i.test(f.name)
  );
  if (!candidates.length) return null;

  candidates.sort((a, b) => {
    if (b.updated !== a.updated) return b.updated - a.updated;
    return b.name.localeCompare(a.name);
  });
  return candidates[0];
}

function unzipToRepoFiles_(zipFile, destPrefix) {
  let blobs;
  try {
    const zipBlob = Utilities.newBlob(zipFile.bytes, 'application/zip', zipFile.name);
    blobs = Utilities.unzip(zipBlob);
  } catch (e) {
    throw new Error(`Cannot unzip ${zipFile.name}: ${e}`);
  }

  const out = [];
  blobs.forEach(blob => {
    const originalName = String(blob.getName() || '').replace(/\\/g, '/');
    if (!originalName || /\/$/.test(originalName)) return;

    const rel = sanitizeRelativePath_(originalName);
    if (!rel) return;

    out.push({
      path: `${destPrefix}/${rel}`,
      bytes: blob.getBytes()
    });
  });

  if (!out.length) throw new Error(`ZIP contains no files: ${zipFile.name}`);
  return out;
}

function sanitizeRelativePath_(path) {
  const parts = String(path)
    .split('/')
    .filter(Boolean)
    .filter(p => p !== '.');

  if (!parts.length || parts.some(p => p === '..')) return '';
  return parts.map(sanitizePathPart_).join('/');
}

function resetSyncState() {
  const p = PropertiesService.getScriptProperties();
  p.deleteProperty('SYNC_STATE');
  p.deleteProperty('WORKSPACE_STATE');
  return 'SYNC_STATE and WORKSPACE_STATE cleared';
}

function removeSyncTriggers_() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'syncDriveToGitHub') ScriptApp.deleteTrigger(t);
  });
}

function getConfig_() {
  const p = PropertiesService.getScriptProperties();
  return {
    token: p.getProperty('GITHUB_TOKEN'),
    owner: p.getProperty('REPO_OWNER') || DEFAULTS.owner,
    repo: p.getProperty('REPO_NAME') || DEFAULTS.repo,
    driveFolderId: p.getProperty('DRIVE_FOLDER_ID') || DEFAULTS.driveFolderId,
    branch: p.getProperty('BRANCH') || DEFAULTS.branch,
    repoPrefix: DEFAULTS.repoPrefix,
    workspacePrefix: DEFAULTS.workspacePrefix
  };
}

function validateConfig_() {
  const cfg = getConfig_();
  if (!cfg.token) throw new Error('Missing Script Property: GITHUB_TOKEN');
  DriveApp.getFolderById(cfg.driveFolderId).getName();
  return true;
}

function collectFiles_(folder, prefix) {
  const out = [];
  walkFolder_(folder, prefix, out);
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

function walkFolder_(folder, prefix, out) {
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    const name = sanitizePathPart_(f.getName());

    // Do not sync the bridge packages themselves.
    if (
      /^AI-ULTRA-DRIVE-GITHUB-BRIDGE(?:-V[0-9.]+)?\.zip$/i.test(name) ||
      name === 'AI-ULTRA-DRIVE-SYNC-WORKFLOW.zip' ||
      /^Code(?:-v[0-9.]+)?\.gs$/i.test(name)
    ) continue;

    const blob = f.getBlob();
    const bytes = blob.getBytes();
    const updated = f.getLastUpdated().getTime();
    out.push({
      driveId: f.getId(),
      name: f.getName(),
      path: `${prefix}/${name}`,
      bytes: bytes,
      updated: updated,
      fingerprint: `${updated}:${bytes.length}:${f.getName()}`
    });
  }

  const folders = folder.getFolders();
  while (folders.hasNext()) {
    const child = folders.next();
    walkFolder_(child, `${prefix}/${sanitizePathPart_(child.getName())}`, out);
  }
}

function sanitizePathPart_(s) {
  return String(s)
    .replace(/[\\]/g, '-')
    .replace(/^\.+$/, '_')
    .replace(/[\u0000-\u001f]/g, '')
    .trim();
}

function ensureBaseHead_(cfg) {
  const repo = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}`);
  const baseBranch = repo.default_branch || 'main';
  let head = getBranchHead_(cfg, baseBranch);
  if (head) return head;

  const content = Utilities.base64Encode(
    Utilities.newBlob('AI Ultra repository bootstrap. Project sync lives in branch drive-sync.\n').getBytes()
  );

  github_(cfg, 'PUT', `/repos/${cfg.owner}/${cfg.repo}/contents/.ai-ultra-bootstrap.md`, {
    message: 'chore: bootstrap repository for Drive sync',
    content: content
  });

  head = getBranchHead_(cfg, baseBranch);
  if (!head) throw new Error(`Could not bootstrap default branch: ${baseBranch}`);
  return head;
}

function getBranchHead_(cfg, branchName) {
  try {
    const ref = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/ref/heads/${encodeURIComponent(branchName)}`);
    const commit = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/commits/${ref.object.sha}`);
    return { commitSha: ref.object.sha, treeSha: commit.tree.sha };
  } catch (e) {
    const s = String(e);
    if (s.includes('GitHub 404') || s.includes('GitHub 409')) return null;
    throw e;
  }
}

function getTreeBlobPaths_(cfg, treeSha) {
  const r = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/trees/${treeSha}?recursive=1`);
  if (r.truncated) throw new Error('GitHub tree is too large/truncated; refusing unsafe stale-file cleanup');
  return (r.tree || []).filter(x => x.type === 'blob').map(x => x.path);
}

function createBlob_(cfg, bytes) {
  const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/blobs`, {
    content: Utilities.base64Encode(bytes),
    encoding: 'base64'
  });
  return r.sha;
}

function createBlobsBatch_(cfg, entries) {
  const out = new Array(entries.length);
  const url = `${API}/repos/${cfg.owner}/${cfg.repo}/git/blobs`;

  for (let start = 0; start < entries.length; start += BLOB_BATCH_SIZE) {
    const batch = entries.slice(start, start + BLOB_BATCH_SIZE);
    const requests = batch.map(e => ({
      url: url,
      method: 'post',
      muteHttpExceptions: true,
      contentType: 'application/json',
      headers: githubHeaders_(cfg),
      payload: JSON.stringify({
        content: Utilities.base64Encode(e.bytes),
        encoding: 'base64'
      })
    }));

    const responses = UrlFetchApp.fetchAll(requests);
    responses.forEach((res, j) => {
      const code = res.getResponseCode();
      const text = res.getContentText();
      let json = {};
      try { json = text ? JSON.parse(text) : {}; } catch (_) { json = { raw: text }; }
      if (code < 200 || code >= 300 || !json.sha) {
        throw new Error(`GitHub blob ${code}: ${json.message || text}`);
      }
      out[start + j] = json.sha;
    });
  }
  return out;
}

function createTree_(cfg, items, baseTreeSha) {
  const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/trees`, {
    base_tree: baseTreeSha,
    tree: items
  });
  if (!r.sha) throw new Error('GitHub did not return a tree SHA');

  // Git objects can be briefly eventually consistent after a large batch.
  waitForTree_(cfg, r.sha);
  return r.sha;
}

function waitForTree_(cfg, treeSha) {
  let lastError = null;
  for (let attempt = 1; attempt <= 6; attempt++) {
    try {
      const tree = github_(cfg, 'GET', `/repos/${cfg.owner}/${cfg.repo}/git/trees/${treeSha}`);
      if (tree && tree.sha === treeSha) return true;
    } catch (e) {
      lastError = e;
    }
    Utilities.sleep(500 * attempt);
  }
  throw new Error(`Created tree is not readable yet: ${treeSha}. ${lastError || ''}`);
}

function createCommit_(cfg, treeSha, parents, message) {
  let lastError = null;
  for (let attempt = 1; attempt <= 6; attempt++) {
    try {
      const r = github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/commits`, {
        message: message,
        tree: treeSha,
        parents: parents
      });
      return r.sha;
    } catch (e) {
      lastError = e;
      const text = String(e);
      if (!text.includes('GitHub 422') || !text.toLowerCase().includes('tree')) throw e;
      waitForTree_(cfg, treeSha);
      Utilities.sleep(750 * attempt);
    }
  }
  throw lastError || new Error('Could not create Git commit');
}

function createBranchRef_(cfg, branchName, commitSha) {
  github_(cfg, 'POST', `/repos/${cfg.owner}/${cfg.repo}/git/refs`, {
    ref: `refs/heads/${branchName}`,
    sha: commitSha
  });
}

function updateBranchRef_(cfg, branchName, commitSha) {
  github_(cfg, 'PATCH', `/repos/${cfg.owner}/${cfg.repo}/git/refs/heads/${encodeURIComponent(branchName)}`, {
    sha: commitSha,
    force: false
  });
}


function githubHeaders_(cfg) {
  return {
    Authorization: `Bearer ${cfg.token}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28'
  };
}

function github_(cfg, method, path, body) {
  const options = {
    method: method,
    muteHttpExceptions: true,
    headers: githubHeaders_(cfg)
  };

  if (body !== undefined) {
    options.contentType = 'application/json';
    options.payload = JSON.stringify(body);
  }

  const res = UrlFetchApp.fetch(API + path, options);
  const code = res.getResponseCode();
  const text = res.getContentText();
  let json = {};
  try { json = text ? JSON.parse(text) : {}; } catch (_) { json = { raw: text }; }

  if (code < 200 || code >= 300) {
    throw new Error(`GitHub ${code}: ${json.message || text}`);
  }
  return json;
}

function loadJsonProperty_(key) {
  const raw = PropertiesService.getScriptProperties().getProperty(key);
  if (!raw) return {};
  try { return JSON.parse(raw); } catch (_) { return {}; }
}

function saveJsonProperty_(key, value) {
  PropertiesService.getScriptProperties().setProperty(key, JSON.stringify(value));
}
