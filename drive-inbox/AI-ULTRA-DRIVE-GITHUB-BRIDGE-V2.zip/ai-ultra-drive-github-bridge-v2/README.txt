AI ULTRA DRIVE -> GITHUB BRIDGE V2

What V2 adds:
- Mirrors GITHUB-INBOX to drive-inbox/ on branch drive-sync.
- Automatically selects the newest ZIP in SEO and CAROUSEL.
- Unpacks them into:
    workspace/seo/current/
    workspace/carousel/current/
- Writes workspace/_CURRENT.json and source manifests.
- Removes stale extracted files when the current ZIP changes.
- Keeps 5-minute automatic sync.

Install:
1. Replace all Code.gs contents in your existing Apps Script project with this Code.gs.
2. Save.
3. Run testConnection (optional verification: bridgeVersion 2.0.0).
4. Run setup once.
5. Check Execution log.

Existing Script Properties stay unchanged.
