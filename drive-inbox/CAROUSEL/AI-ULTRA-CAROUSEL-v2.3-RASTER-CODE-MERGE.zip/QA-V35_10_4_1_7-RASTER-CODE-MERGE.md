# QA — V35.10.4.1.7 Raster Code Merge

- Source raster: supplied transparent gold frame PNG.
- Integration method: Three.js texture layer, not baked into screenshots and not CSS background.
- Active cards: raster is attached as a child mesh to every one of the 7 reusable foreground card slots.
- Background stream: the same raster is rendered by one InstancedMesh over all 2160 flow cards.
- Existing glass, LED/bloom, scroll, funnel, numbering, hover, CTA and ring-wrap logic remain unchanged.
- Transparent center of the PNG preserves the procedural glass beneath it.
- Runtime fallback: if the PNG fails to load, the original procedural-glass carousel still runs.
