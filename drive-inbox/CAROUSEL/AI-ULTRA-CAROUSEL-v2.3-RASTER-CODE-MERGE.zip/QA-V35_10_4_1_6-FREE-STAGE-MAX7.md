# V35.10.4.1.6 — FREE STAGE / HARD MAX 7

- Foreground active layer has exactly 7 reusable physical meshes and renders only the current logical set.
- Visible active count is hard-clamped to 4–7. Cards outside the current set are immediately hidden; no 8th/9th micro-tail remains.
- Settled support layout is free-positioned: supports use different vertical offsets and slight depth variation on every completed scroll.
- 50% overlap is a maximum, not a target. Horizontal center spacing guarantees no support can cover more than 50% of a neighboring support width; hero/support overlap is capped by the same rule.
- Active supports keep a stable readable size instead of shrinking with distance.
- Raster-free contract remains intact: no PNG/JPG/JPEG/WebP/GIF/AVIF assets or data:image payloads.
