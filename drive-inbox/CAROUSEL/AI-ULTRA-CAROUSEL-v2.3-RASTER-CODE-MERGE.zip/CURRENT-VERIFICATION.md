# AI Ultra Carousel — current verified build

Verified on 2026-09-18 from the latest `FREE-STAGE-MAX7-MAX50-OVERLAP` build.

## Preserved latest requirements
- Raster-free foreground and package: no PNG/JPG/JPEG/WebP/GIF/AVIF/BMP/TIFF assets and no `data:image` payloads in `index.html`.
- Gold → champagne → warm-white LED gradient remains on active card side rails and background flow cards.
- Foreground glass remains high-transmission with a light frosted blur (`transmission .90`, `roughness .18`, `thickness .055`).
- Active foreground mesh pool is exactly 7 cards.
- Visible active count is hard-clamped to 4–7.
- Cards outside the current active set are hidden immediately; there are no 8th/9th micro-tail active cards.
- Settled support cards use varied vertical offsets and slight depth variation.
- 50% overlap is a hard maximum, not a target; additional spacing may reduce overlap.
- Background flow remains procedural and continuous.

## Verification performed
- ZIP structure checked.
- JavaScript module passes `node --check` syntax validation.
- No raster asset files found in the package.
- No raster references or `data:image` payloads found in `index.html`.
- Active-card constants confirmed: `ACTIVE_CARD_COUNT=7`, `MIN_VISIBLE_ACTIVE=4`, `MAX_VISIBLE_ACTIVE=7`.
- Stale comments referring to the old 1–5 active-card model were corrected; runtime behavior was not changed by this cleanup.
