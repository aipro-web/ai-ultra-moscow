# QA — V2.3 Raster Fusion

- Source raster: `assets/card-raster-frame.png` (the user-supplied transparent PNG).
- Active cards: raster is a real child `THREE.Mesh` using the same rounded card geometry and UVs.
- Background stream: raster is instanced in one draw call and shares the exact matrix buffer with the 2160 flow cards.
- Raster inherits position, scale, hover, grab, flip and carousel motion in code; there is no CSS/image overlay.
- Existing glass and LED layers remain intact beneath/above the raster.
- Explicit render ordering keeps the raster face above the glass body.
- sRGB texture handling, anisotropy and clamp-to-edge are enabled.
- Funnel/scroll/ring logic is unchanged.
