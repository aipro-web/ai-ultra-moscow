# AI Carousel v2

Raster-free active carousel built from AI Carousel v1.

Changes in v2:
- removed all raster card loading/rendering and raster assets;
- background spiral remains untouched;
- active hero remains centered;
- after each completed scroll, visible support cards settle into a new randomized, collision-aware composition;
- active count stays between 4 and 7;
- existing scroll, funnel, ring-wrap, hover, grab and flip behavior is preserved.

## V2.3 raster fusion
The supplied transparent gold frame is included at `assets/card-raster-frame.png` and is fused in Three.js to both active cards and the instanced background flow. Run through a local/static web server so module imports, the path JSON and texture resolve correctly.

## V35.10.4.1.7 — Raster code merge
The supplied transparent gold card frame is loaded from `assets/card-raster-frame.png` and fused in Three.js as a texture layer on both active cards and the 2160-card background stream. The existing glass/LED/scroll/funnel behavior is retained.
