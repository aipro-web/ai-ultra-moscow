import * as THREE from 'https://esm.sh/three@0.184.0';
    import { EffectComposer } from 'https://esm.sh/three@0.184.0/addons/postprocessing/EffectComposer.js';
    import { RenderPass } from 'https://esm.sh/three@0.184.0/addons/postprocessing/RenderPass.js';
    import { UnrealBloomPass } from 'https://esm.sh/three@0.184.0/addons/postprocessing/UnrealBloomPass.js';
    import { OutputPass } from 'https://esm.sh/three@0.184.0/addons/postprocessing/OutputPass.js';
    import { gsap } from 'https://esm.sh/gsap@3.15.0';
    import { Observer } from 'https://esm.sh/gsap@3.15.0/Observer';
    gsap.registerPlugin(Observer);

    // V35.10.6 changes the ambient motion model: the background carousel no longer rotates around a shared center.
    // Instead, every background card advances clockwise along the original Pass 4 path like wagons on rails,
    // staying inside the carousel silhouette while remaining face-on to the viewer.
    // Foreground funnel cards remain readable and all V35.10.4 scroll / ring-wrap / grab / bloom mechanics are preserved.
    // V35.10 FUNNEL-STEP-ON-STOP: built from clean V35. Visual Pass 4 scroll is untouched; only logical funnel numbering changes on full stop.
    // CRITICAL CONTRACT: the original Pass 4 visual scroll stays byte-for-byte in behavior at the Observer target update:
    // targetT -= deltaY * SENSITIVITY; setCamT(targetT). Logical numbering is a separate state machine.
    // Initial logical group is 1..5 with hero 1. During active scrolling the logical hero is frozen.
    // After the original visual motion fully stops, one completed gesture advances exactly ONE funnel step (+1 / -1),
    // regardless of how far/fast the visual camera travelled or how many physical cards crossed the viewport.
    // Desktop wheel response is the original continuous Pass 4 motion: every wheel impulse only retargets the visual camera.
    // Logical content order does not advance per wheel event; it advances once, only after the whole visual motion has settled.
    // Repeated impulses retarget the same power3.out camera tween, matching the original Pass 4 1.0s motion feel.
    // Pure Carousel Core: only visual mechanics and UI-control hooks remain.
    // Only visual mechanics remain: Pass 4 flow, card geometry, numbering, hover/drag/scroll and blue UI satellites.
    // Production flow, 1..7 active-card model, ring seam 500 <-> 1 and glass mechanics remain intact.

    const PATH_URL='https://raw.githubusercontent.com/gaspoorf/curve-gallery/main/public/paths/path4.json';

    const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
    renderer.setPixelRatio(Math.min(devicePixelRatio,2));
    renderer.setSize(innerWidth,innerHeight);
    renderer.outputColorSpace=THREE.SRGBColorSpace;
    document.getElementById('canvas-container').appendChild(renderer.domElement);

    const scene=new THREE.Scene();
    scene.background=new THREE.Color(0x050607);
    scene.fog=new THREE.Fog(0x050607,11,49);
    const camera=new THREE.PerspectiveCamera(60,innerWidth/innerHeight,.1,200);

    // V35.10.3: edge-light technique adapted from the referenced CodePen.
    // The source demo uses bright emissive edges + UnrealBloomPass; here bloom is shared globally,
    // while only 7 active foreground cards receive the hot LED edge layer.
    const renderPass=new RenderPass(scene,camera);
    const bloomPass=new UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),.58,.34,.92);
    bloomPass.threshold=1.00;
    bloomPass.strength=.72;
    bloomPass.radius=.42;
    const outputPass=new OutputPass();
    const composer=new EffectComposer(renderer);
    composer.addPass(renderPass);
    composer.addPass(bloomPass);
    composer.addPass(outputPass);

    const SCALE=16;
    const TOTAL=2160; // production dense flow
    const FLOW_LOOP_SECONDS=14; // one full clockwise pass of the background flow along the original curve
    const FLOW_CLOCKWISE_SPEED=1/FLOW_LOOP_SECONDS;
    const CAM_Z=7.4;
    const CARD_HEIGHT=1;
    const CARD_WIDTH=9/16;
    const CARD_RADIUS=CARD_WIDTH*.205;
    const SENSITIVITY=0.8/(window.innerHeight*4);
    const ORIGINAL_SEQUENCE_TOTAL=500;
    const FOCUS_DIST=5.5;
    const FLOW_MAX_SCALE=2.25;
    const Z_GATE=11;
    const ACTIVE_CARD_COUNT=7;
    const MIN_VISIBLE_ACTIVE=4;
    const MAX_VISIBLE_ACTIVE=7;
    const INITIAL_GROUP_SIZE=5;
    const ORBITAL_SQUARE_COUNT=10;
    const ORBITAL_SQUARE_RADIUS_X_NDC=.60;
    const ORBITAL_SQUARE_RADIUS_Y_NDC=.46;
    const ORBITAL_SQUARE_SCREEN_SIZE=.145; // V35.10.8: 2.5x larger than V35.10.7
    const ORBITAL_SQUARE_ROTATION_SPEED=2.65;
    const ORBITAL_SQUARE_CARD_CLEARANCE_NDC=.035;
    const ORBITAL_SQUARE_EDGE_MARGIN_NDC=.035;
    const ORBITAL_SQUARE_SEARCH_STEP=Math.PI/24;
    const ORBITAL_SQUARE_SEARCH_STEPS=72;
    const ORBITAL_SQUARE_RADIAL_LEVELS=[1,1.14,1.30,1.48,1.68,1.90,2.15,2.40];
    const ORBITAL_FLOW_SQUARE_COUNT=180;
    const TINY_ORBITAL_FLOW_ENABLED=false; // V114.2: remove tiny blue square particles
    const ORBITAL_FLOW_SQUARE_SIZE_MIN=.105;
    const ORBITAL_FLOW_SQUARE_SIZE_MAX=.235;
    const GROUP_GESTURE_GAP_MS=230;
    const GROUP_SETTLE_TIMEOUT_MS=1350;
    const GROUP_VISUAL_STOP_EPSILON=.00005;
    const GROUP_SIZE_THRESHOLDS=[8,18,30,50,85,130];
    const ORIGINAL_PASS4_QUICKTO_DURATION=1;
    // Manual wheel movement uses the exact original Pass 4 tween timing/ease.
    // One accepted wheel impulse = one adjacent logical card; repeated impulses retarget continuously.
    const MANUAL_STEP_DURATION=ORIGINAL_PASS4_QUICKTO_DURATION;
    const PROGRAMMATIC_MIN_DURATION=ORIGINAL_PASS4_QUICKTO_DURATION;
    const PROGRAMMATIC_MAX_DURATION=2.40;
    const PROGRAMMATIC_SECONDS_PER_CARD=.11;
    const MANUAL_WHEEL_REFRACTORY_MS=28;
    const MANUAL_TOUCH_STEP_ENERGY=18;
    const MANUAL_TOUCH_IDLE_MS=150;
    const MANUAL_IMPULSE_EVENT_CAP=120;
    const ACTIVE_VISIBILITY_DAMP=13;
    const GESTURE_GAP_MS=230;
    // Accumulated absolute Observer delta needed to reveal card #2, #3, #4 and #5.
    // Deliberately conservative: one ordinary wheel notch should not summon all five.
    const ACTIVE_REVEAL_THRESHOLDS=[8,18,30,50];
    const ACTIVE_REVEAL_EVENT_CAP=180;
    const HERO_SCREEN_HEIGHT=.80;
    const MIN_ACTIVE_SCREEN_HEIGHT=.38;
    const ACTIVE_FOCUS_RADIUS_CARDS=2.15;
    const ACTIVE_RECYCLE_FADE_START=3.18;
    const ACTIVE_RECYCLE_FADE_END=3.48;
    const ACTIVE_LATERAL_MAX=1.08;
    const ACTIVE_DEPTH_MAX=.42;
    const SIDE_LANE_X_NDC=.34;
    const SIDE_LANE_X_FAR_NDC=.50;
    const SIDE_LANE_Y_NDC=.105;
    const SIDE_LANE_Y_FAR_NDC=.245;
    const SIDE_LANE_DEPTH=.22;
    const SUPPORT_LANE_DAMP_MOVING=10.5;
    const SUPPORT_LANE_DAMP_SETTLE=4.6;
    const SETTLE_DELAY_MS=165;
    const HERO_RENDER_ORDER=3200;
    const SUPPORT_SECOND_RENDER_ORDER=1750;
    const SUPPORT_THIRD_RENDER_ORDER=900;
    const HOVER_RENDER_ORDER=2450;
    const HOVER_VIEWPORT_MARGIN_NDC=.035;
    const HOVER_DAMP=12;
    const HERO_FLIP_DAMP=14;
    const GRAB_DAMP=18;
    const GRAB_RELEASE_DAMP=12;
    const GRAB_RENDER_ORDER=3900;
    const GRAB_MOVE_THRESHOLD_PX=7;
    const GRAB_VIEWPORT_MARGIN_NDC=.035;
    const CARD_NUMBER_PAD_X=.055;
    const CARD_NUMBER_PAD_Y=.060;
    const NAVIGATION_ARRIVAL_EPSILON=.0025;
    const MANUAL_GESTURE_ARRIVAL_EPSILON=.0025;

    function randomBetween(a,b){return a+Math.random()*(b-a)}
    function wrap01(v){return ((v%1)+1)%1}
    function mod(v,m){return ((v%m)+m)%m}
    function hash01(seed){const x=Math.sin(seed*12.9898+78.233)*43758.5453123;return x-Math.floor(x)}
    function buildCurve(raw){return new THREE.CatmullRomCurve3(raw.map(([x,y,z])=>new THREE.Vector3(x*SCALE,y*SCALE,z*SCALE)),true,'catmullrom',.5)}
    function curveFrame(curve,t){const pos=curve.getPoint(t),tan=curve.getTangent(t);return {pos,nx:-tan.y,ny:tan.x}}
    function roundedRectShape(w,h,r){
      const x=-w/2,y=-h/2; r=Math.min(r,w/2,h/2); const s=new THREE.Shape();
      s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);
      s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
      s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);
      s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);s.closePath();return s;
    }
    function showError(message){if(window.__AIULTRA_SHOW_FATAL__) return window.__AIULTRA_SHOW_FATAL__(message);const el=document.getElementById('status');el.textContent=message;el.classList.add('show')}

    const baseGeometry=new THREE.ShapeGeometry(roundedRectShape(CARD_WIDTH,CARD_HEIGHT,CARD_RADIUS),8);
    baseGeometry.computeVertexNormals();
    {
      const pos=baseGeometry.getAttribute('position');
      const uv=new Float32Array(pos.count*2);
      for(let i=0;i<pos.count;i++){
        uv[i*2]=(pos.getX(i)+CARD_WIDTH*.5)/CARD_WIDTH;
        uv[i*2+1]=(pos.getY(i)+CARD_HEIGHT*.5)/CARD_HEIGHT;
      }
      baseGeometry.setAttribute('uv',new THREE.BufferAttribute(uv,2));
    }
    const edgeGeometry=new THREE.EdgesGeometry(baseGeometry,24);

    // CodePen-inspired LED edge layer: HDR-bright line color is fed into UnrealBloomPass.
    // The fragment mask keeps the long left/right sides luminous and concentrates extra energy at corners;
    // top/bottom remain deliberately restrained so the result reads as glass, not a CSS outline.
    function makeBloomEdgeMaterial(intensity=1){
      return new THREE.ShaderMaterial({
        transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending,
        toneMapped:false,
        uniforms:{uIntensity:{value:intensity}},
        vertexShader:`
          varying vec2 vEdgeLocal;
          void main(){
            vEdgeLocal=position.xy;
            vec4 mv=modelViewMatrix*vec4(position,1.);
            gl_Position=projectionMatrix*mv;
          }`,
        fragmentShader:`
          varying vec2 vEdgeLocal;
          uniform float uIntensity;
          void main(){
            float nx=clamp(abs(vEdgeLocal.x)/${(9/16/2).toFixed(8)},0.,1.);
            float ny=clamp(abs(vEdgeLocal.y)/${(1/2).toFixed(8)},0.,1.);
            float vertical=smoothstep(.78,.985,nx);
            float corner=vertical*smoothstep(.70,.985,ny);
            float horizontal=smoothstep(.94,.998,ny)*(1.-smoothstep(.62,.88,nx));
            float energy=vertical*(1.55+corner*1.45)+horizontal*.12;
            vec3 warm=vec3(1.22,.91,.48);
            vec3 hot=vec3(1.75,1.58,1.28);
            vec3 color=mix(warm,hot,clamp(.35+corner*.65,0.,1.))*energy*uIntensity;
            float alpha=clamp((vertical*.78+corner*.62+horizontal*.08)*uIntensity,0.,1.);
            gl_FragColor=vec4(color,alpha);
          }`
      });
    }
    const bloomEdgeHeroMaterial=makeBloomEdgeMaterial(1.34);
    const bloomEdgeSupportMaterial=makeBloomEdgeMaterial(1.02);

    function makeGlassMaterial(depthTest=true,dynamicFlow=false){
      const flowUniforms={uDenseGlass:{value:dynamicFlow?0:1}};
      if(dynamicFlow){
        Object.assign(flowUniforms,{
          uCurveT:{value:0},uCameraPos:{value:new THREE.Vector3()},uFocusTGate:{value:.02},
          uFocusDist:{value:FOCUS_DIST},uZGate:{value:Z_GATE},uMaxScale:{value:FLOW_MAX_SCALE},
          uOrbitAngle:{value:0},uOrbitPivot:{value:new THREE.Vector2()}
        });
      }
      return new THREE.ShaderMaterial({
        transparent:true,depthWrite:false,depthTest,side:THREE.DoubleSide,blending:THREE.NormalBlending,
        uniforms:flowUniforms,
        vertexShader:`
          varying vec2 vLocal; varying float vDepth;
          ${dynamicFlow?`
          attribute float instanceT;
          uniform float uCurveT; uniform vec3 uCameraPos; uniform float uFocusTGate;
          uniform float uFocusDist; uniform float uZGate; uniform float uMaxScale;
          uniform float uOrbitAngle; uniform vec2 uOrbitPivot;
          `:''}
          void main(){
            vec3 p=position;
            ${dynamicFlow?`
            #ifdef USE_INSTANCING
              float wrappedDt=abs(instanceT-uCurveT); if(wrappedDt>.5) wrappedDt=1.-wrappedDt;
              vec3 instanceCenter=vec3(instanceMatrix[3].xyz);
              float c=cos(uOrbitAngle), sn=sin(uOrbitAngle);
              vec2 rel=instanceCenter.xy-uOrbitPivot;
              vec2 orbitCenter=uOrbitPivot+vec2(c*rel.x-sn*rel.y,sn*rel.x+c*rel.y);
              float distXY=length(uCameraPos.xy-orbitCenter);
              float dz=abs(uCameraPos.z-instanceCenter.z);
              float focusScale=1.;
              if(wrappedDt<uFocusTGate && dz<uZGate && distXY<uFocusDist){
                float f=clamp(1.-distXY/uFocusDist,0.,1.);
                focusScale=1.+f*f*f*(uMaxScale-1.);
              }
              p.xy*=focusScale;
            #endif
            `:''}
            vLocal=position.xy;
            vec4 localPosition=vec4(p,1.);
            #ifdef USE_INSTANCING
              // Orbit only the instance center around the carousel pivot.
              // Keep the local quad axes unchanged so every card remains face-on instead of spinning with the orbit.
              vec3 originalCenter=vec3(instanceMatrix[3].xyz);
              vec3 worldP=(instanceMatrix*localPosition).xyz;
              vec3 localFromCenter=worldP-originalCenter;
              float c2=cos(uOrbitAngle), sn2=sin(uOrbitAngle);
              vec2 rel2=originalCenter.xy-uOrbitPivot;
              vec2 rotatedCenter=uOrbitPivot+vec2(c2*rel2.x-sn2*rel2.y,sn2*rel2.x+c2*rel2.y);
              localPosition=vec4(vec3(rotatedCenter,originalCenter.z)+localFromCenter,1.);
            #endif
            vec4 mv=modelViewMatrix*localPosition;
            vDepth=-mv.z;
            gl_Position=projectionMatrix*mv;
          }`,
        fragmentShader:`
          varying vec2 vLocal; varying float vDepth;
          uniform float uDenseGlass;
          void main(){
            vec2 uv=vec2(vLocal.x/${CARD_WIDTH.toFixed(8)}+.5,vLocal.y/${CARD_HEIGHT.toFixed(8)}+.5);
            float edge=min(min(uv.x,1.-uv.x),min(uv.y,1.-uv.y));
            float rim=1.-smoothstep(.014,.122,edge);
            float top=smoothstep(.10,1.,uv.y);
            float sideShape=pow(abs(uv.x-.5)*2.,2.12);
            float fade=clamp(1.-max(vDepth-8.,0.)/38.,.32,1.);
            vec3 cold=vec3(.60,.67,.74), frostWhite=vec3(.955,.972,.985);
            vec3 base=mix(cold,frostWhite,.34+.34*top);
            base=mix(base,frostWhite,(1.-rim)*(.055+.030*top));
            base+=rim*.070+sideShape*.030;
            float sideLed=smoothstep(.74,.985,abs(uv.x-.5)*2.);
            float sideCore=smoothstep(.86,.995,abs(uv.x-.5)*2.);
            float sideFalloff=.86-.18*smoothstep(.0,.10,uv.y)-.18*smoothstep(.0,.10,1.-uv.y);
            float tl=1.-smoothstep(.02,.30,length(uv-vec2(0.,1.)));
            float tr=1.-smoothstep(.02,.30,length(uv-vec2(1.,1.)));
            float bl=1.-smoothstep(.02,.30,length(uv-vec2(0.,0.)));
            float br=1.-smoothstep(.02,.30,length(uv-vec2(1.,0.)));
            float corner=max(max(tl,tr),max(bl,br));
            vec3 ledWarm=vec3(1.,.86,.58);
            vec3 ledWhite=vec3(1.,.985,.95);
            vec3 sideColor=mix(ledWarm,ledWhite,.55+.18*top);
            vec3 color=base
              + sideColor*(sideLed*.22*sideFalloff + sideCore*.16)
              + ledWarm*corner*.12;
            float lightAlpha=(.094+.046*top+.050*rim+.018*sideShape + sideLed*.070 + sideCore*.045 + corner*.018)*1.18*fade;
            vec3 smoked=vec3(.045,.060,.082);
            color=mix(color,smoked,uDenseGlass*.70);
            float denseAlpha=(.78+.08*rim+.045*sideLed+.025*corner)*fade;
            float alpha=mix(lightAlpha,denseAlpha,uDenseGlass);
            gl_FragColor=vec4(color,alpha);
          }`
      });
    }

    function makeFlowSideGlowMaterial(){
      return new THREE.ShaderMaterial({
        transparent:true,depthWrite:false,depthTest:true,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,toneMapped:false,
        vertexShader:`
          varying vec2 vLocal;
          void main(){
            vLocal=position.xy;
            vec4 mv=modelViewMatrix*vec4(position,1.);
            gl_Position=projectionMatrix*mv;
          }`,
        fragmentShader:`
          varying vec2 vLocal;
          void main(){
            vec2 uv=vec2(vLocal.x/${CARD_WIDTH.toFixed(8)}+.5,vLocal.y/${CARD_HEIGHT.toFixed(8)}+.5);
            float side=smoothstep(.74,.992,abs(uv.x-.5)*2.);
            float core=smoothstep(.88,.998,abs(uv.x-.5)*2.);
            float corner=(1.-smoothstep(.04,.34,min(min(length(uv-vec2(0.,0.)),length(uv-vec2(1.,0.))),min(length(uv-vec2(0.,1.)),length(uv-vec2(1.,1.))))));
            float fadeY=.82-.12*smoothstep(.0,.16,uv.y)-.12*smoothstep(.0,.16,1.-uv.y);
            float alpha=(side*.22+core*.28+corner*.16)*fadeY;
            vec3 warm=vec3(1.00,.90,.70);
            vec3 ice=vec3(.96,.99,1.08);
            vec3 color=mix(warm,ice,.68)*(side*.90+core*1.05+corner*.55);
            gl_FragColor=vec4(color,alpha);
          }`
      });
    }

    const flowMaterial=makeGlassMaterial(true,true);
    const flowSideGlowMaterial=makeFlowSideGlowMaterial();
    const overlayGlass=makeGlassMaterial(false,false);
    const overlayEdge=new THREE.LineBasicMaterial({color:0xf6dfad,transparent:true,opacity:.15,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending});
    const backGlass=new THREE.MeshBasicMaterial({color:0x2a2115,transparent:true,opacity:.24,depthWrite:false,depthTest:false,side:THREE.BackSide,blending:THREE.NormalBlending});

    const orbitalSquareGeometry=new THREE.ShapeGeometry(roundedRectShape(1,1,.22),6);
    const orbitalSquareEdgeGeometry=new THREE.EdgesGeometry(orbitalSquareGeometry,18);
    function makeOrbitalSquareMaterial(depthTest=false,dynamicFlow=false){
      const uniforms=dynamicFlow?{
        uCurveT:{value:0},uCameraPos:{value:new THREE.Vector3()},uFocusTGate:{value:.02},
        uFocusDist:{value:FOCUS_DIST},uZGate:{value:Z_GATE},uMaxScale:{value:FLOW_MAX_SCALE}
      }:{};
      return new THREE.ShaderMaterial({
        transparent:true,depthWrite:false,depthTest,side:THREE.DoubleSide,blending:THREE.NormalBlending,toneMapped:false,
        uniforms,
        vertexShader:`
          varying vec2 vUv2; varying float vDepth;
          ${dynamicFlow?`
          attribute float instanceT;
          uniform float uCurveT; uniform vec3 uCameraPos; uniform float uFocusTGate;
          uniform float uFocusDist; uniform float uZGate; uniform float uMaxScale;
          `:''}
          void main(){
            vec3 p=position;
            ${dynamicFlow?`
            #ifdef USE_INSTANCING
              float wrappedDt=abs(instanceT-uCurveT); if(wrappedDt>.5) wrappedDt=1.-wrappedDt;
              vec3 instanceCenter=vec3(instanceMatrix[3].xyz);
              float distXY=length(uCameraPos.xy-instanceCenter.xy);
              float dz=abs(uCameraPos.z-instanceCenter.z);
              float focusScale=1.;
              if(wrappedDt<uFocusTGate && dz<uZGate && distXY<uFocusDist){
                float f=clamp(1.-distXY/uFocusDist,0.,1.);
                focusScale=1.+f*f*f*(uMaxScale-1.);
              }
              p.xy*=focusScale;
            #endif
            `:''}
            vUv2=position.xy+.5;
            vec4 localPosition=vec4(p,1.);
            #ifdef USE_INSTANCING
              localPosition=instanceMatrix*localPosition;
            #endif
            vec4 mv=modelViewMatrix*localPosition;
            vDepth=-mv.z;
            gl_Position=projectionMatrix*mv;
          }`,
        fragmentShader:`
          varying vec2 vUv2; varying float vDepth;
          void main(){
            float edge=min(min(vUv2.x,1.-vUv2.x),min(vUv2.y,1.-vUv2.y));
            float rim=1.-smoothstep(.045,.18,edge);
            float core=1.-smoothstep(.18,.46,edge);
            float diag=smoothstep(-.42,.62,(vUv2.x*.78+vUv2.y)-.35);
            float depthFade=clamp(1.-max(vDepth-8.,0.)/42.,.34,1.);
            vec3 navy=vec3(.015,.045,.085);
            vec3 ice=vec3(.62,.86,1.08);
            vec3 electric=vec3(.20,.54,1.18);
            vec3 color=mix(navy,ice,.16+.18*diag)+rim*vec3(.12,.28,.46)+electric*rim*.08;
            float alpha=(.19+.10*diag+.16*rim+.035*core)*depthFade;
            gl_FragColor=vec4(color,alpha);
          }`
      });
    }
    const orbitalSquareGlassMaterial=makeOrbitalSquareMaterial(false,false);
    const orbitalFlowSquareMaterial=makeOrbitalSquareMaterial(true,true);
    const orbitalSquareEdgeMaterial=new THREE.ShaderMaterial({
      transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending,toneMapped:false,
      vertexShader:`void main(){gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
      fragmentShader:`
        void main(){
          vec3 c=vec3(1.55,1.88,2.24);
          gl_FragColor=vec4(c,.86);
        }`
    });
    // V114.1: foreground cards are deliberately raster-free.
    // New artwork can be plugged in later without changing the carousel motion core.

    window.addEventListener('error',e=>{console.error(e.error||e.message);showError('Runtime error: '+(e.message||'unknown error'))});
    window.addEventListener('unhandledrejection',e=>{console.error(e.reason);showError('Runtime error: '+(e.reason?.message||String(e.reason||'unknown error')))});

    async function init(){
      let raw;
      try{
        const r=await fetch(PATH_URL,{mode:'cors',cache:'no-store'});
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        raw=await r.json();
      }catch(error){
        console.error(error);
        showError('Pass 4 path data could not be loaded. Open the root index.html through VS Code Live Server with internet access.');
        return;
      }

      document.body.classList.add('scene-ready');
      const curve=buildCurve(raw);
      const orbitBounds=new THREE.Box2();
      for(const [x,y] of raw) orbitBounds.expandByPoint(new THREE.Vector2(x*SCALE,y*SCALE));
      const orbitPivot=orbitBounds.getCenter(new THREE.Vector2());
      flowMaterial.uniforms.uOrbitPivot.value.copy(orbitPivot);

      // Background flow now advances along the original Pass 4 path instead of orbiting around a shared center.
      // Cards therefore stay inside the carousel silhouette while still moving clockwise as one continuous ribbon.
      const flowGeometry=baseGeometry.clone();
      const instanceTs=new Float32Array(TOTAL);
      flowGeometry.setAttribute('instanceT',new THREE.InstancedBufferAttribute(instanceTs,1));
      const flow=new THREE.InstancedMesh(flowGeometry,flowMaterial,TOTAL);
      const flowSideGlow=new THREE.InstancedMesh(flowGeometry,flowSideGlowMaterial,TOTAL);
      flow.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      flowSideGlow.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      flow.frustumCulled=false; flow.renderOrder=1;
      flowSideGlow.frustumCulled=false; flowSideGlow.renderOrder=2;
      const dummy=new THREE.Object3D();
      const flowMeta=new Array(TOTAL);
      for(let i=0;i<TOTAL;i++){
        const t=i/TOTAL;
        const lateral=randomBetween(-1.42,1.42),depth=randomBetween(-1.20,1.20),size=randomBetween(.082,.205);
        flowMeta[i]={baseT:t,lateral,depth,size};
        instanceTs[i]=t;
      }
      function updateFlowInstances(offsetT){
        for(let i=0;i<TOTAL;i++){
          const meta=flowMeta[i];
          const t=wrap01(meta.baseT+offsetT);
          instanceTs[i]=t;
          const {pos,nx,ny}=curveFrame(curve,t);
          dummy.position.set(pos.x+nx*meta.lateral,pos.y+ny*meta.lateral,pos.z+meta.depth);
          dummy.scale.setScalar(meta.size);
          dummy.rotation.set(0,0,0);
          dummy.updateMatrix();
          flow.setMatrixAt(i,dummy.matrix);
          flowSideGlow.setMatrixAt(i,dummy.matrix);
        }
        flowGeometry.getAttribute('instanceT').needsUpdate=true;
        flow.instanceMatrix.needsUpdate=true;
        flowSideGlow.instanceMatrix.needsUpdate=true;
      }
      updateFlowInstances(0);
      flowMaterial.uniforms.uFocusTGate.value=(FOCUS_DIST*1.5)/curve.getLength();
      scene.add(flow);
      scene.add(flowSideGlow);

      // V35.10.8: blue square satellites are now part of the moving ribbon itself.
      // They use the same curve offset, clockwise timing, face-on orientation and focus scaling as the flow cards.
      const orbitalFlowGeometry=orbitalSquareGeometry.clone();
      const orbitalFlowInstanceTs=new Float32Array(ORBITAL_FLOW_SQUARE_COUNT);
      orbitalFlowGeometry.setAttribute('instanceT',new THREE.InstancedBufferAttribute(orbitalFlowInstanceTs,1));
      const orbitalFlowSquares=new THREE.InstancedMesh(orbitalFlowGeometry,orbitalFlowSquareMaterial,ORBITAL_FLOW_SQUARE_COUNT);
      orbitalFlowSquares.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      orbitalFlowSquares.frustumCulled=false;
      orbitalFlowSquares.renderOrder=1;
      const orbitalFlowMeta=new Array(ORBITAL_FLOW_SQUARE_COUNT);
      for(let i=0;i<ORBITAL_FLOW_SQUARE_COUNT;i++){
        const baseT=wrap01((i+.38)/ORBITAL_FLOW_SQUARE_COUNT + (hash01(i*7.13+2.7)-.5)/ORBITAL_FLOW_SQUARE_COUNT*.55);
        const lateral=(hash01(i*13.71+1.9)*2-1)*1.58;
        const depth=(hash01(i*23.11+5.1)*2-1)*1.16;
        const size=THREE.MathUtils.lerp(ORBITAL_FLOW_SQUARE_SIZE_MIN,ORBITAL_FLOW_SQUARE_SIZE_MAX,hash01(i*31.17+7.4));
        orbitalFlowMeta[i]={baseT,lateral,depth,size};
        orbitalFlowInstanceTs[i]=baseT;
      }
      function updateOrbitalFlowSquares(offsetT){
        for(let i=0;i<ORBITAL_FLOW_SQUARE_COUNT;i++){
          const meta=orbitalFlowMeta[i];
          const t=wrap01(meta.baseT+offsetT);
          orbitalFlowInstanceTs[i]=t;
          const {pos,nx,ny}=curveFrame(curve,t);
          dummy.position.set(pos.x+nx*meta.lateral,pos.y+ny*meta.lateral,pos.z+meta.depth);
          dummy.scale.setScalar(meta.size);
          dummy.rotation.set(0,0,0);
          dummy.updateMatrix();
          orbitalFlowSquares.setMatrixAt(i,dummy.matrix);
        }
        orbitalFlowGeometry.getAttribute('instanceT').needsUpdate=true;
        orbitalFlowSquares.instanceMatrix.needsUpdate=true;
      }
      updateOrbitalFlowSquares(0);
      orbitalFlowSquareMaterial.uniforms.uFocusTGate.value=(FOCUS_DIST*1.5)/curve.getLength();
      if(TINY_ORBITAL_FLOW_ENABLED) scene.add(orbitalFlowSquares);

      // Five interactive cards. Their identity is a real unbounded sequence step;
      // wrapping only changes the displayed number / curve sample, never the direction logic.
      const activeCards=[];
      for(let i=0;i<ACTIVE_CARD_COUNT;i++){
        const card=new THREE.Mesh(baseGeometry,overlayGlass);
        const border=new THREE.LineSegments(edgeGeometry,overlayEdge); border.position.z=.0015; card.add(border);
        const edgeGlow=new THREE.LineSegments(edgeGeometry,bloomEdgeSupportMaterial); edgeGlow.position.z=.0032; card.add(edgeGlow);
        const backFace=new THREE.Mesh(baseGeometry,backGlass); backFace.position.z=-.002; card.add(backFace);
        const label=document.createElement('div'); label.className='card-number'; document.body.appendChild(label);
        card.userData={
          sequenceStep:null,sequenceNumber:0,hoverMix:0,grabMix:0,label,backFace,edgeGlow,
          basePosition:new THREE.Vector3(),baseScale:1,presence:1,visibilityMix:0,
          laneX:0,laneY:0,laneZ:0,laneInitialized:false
        };
        card.visible=true; activeCards.push(card); scene.add(card);
      }

      // Exactly 10 large blue UI satellites. They are pure carousel controls, not site content.
      const orbitalSquares=[];
      const orbitalSquareSizeFactors=[.96,1.04,1.00,1.10,1.02,.98,1.06,.94,1.08,1.00];
      const orbitalButtonActions=['search','menu','music-off',null,null,null,null,null,null,null];
      const orbitalVectorIconMaterial=new THREE.LineBasicMaterial({
        color:0xffffff,transparent:true,opacity:.96,depthTest:false,depthWrite:false,toneMapped:false
      });
      function orbitalVectorLine(points,loop=false){
        const geometry=new THREE.BufferGeometry().setFromPoints(points.map(([x,y])=>new THREE.Vector3(x,y,.018)));
        const line=loop?new THREE.LineLoop(geometry,orbitalVectorIconMaterial):new THREE.Line(geometry,orbitalVectorIconMaterial);
        line.renderOrder=50003;
        return line;
      }
      function buildOrbitalVectorIcon(type){
        const icon=new THREE.Group(); icon.position.z=.018;
        if(type==='search'){
          const ring=[];
          for(let i=0;i<28;i++){const a=(i/28)*Math.PI*2;ring.push([-.055+Math.cos(a)*.18,.055+Math.sin(a)*.18]);}
          icon.add(orbitalVectorLine(ring,true));
          icon.add(orbitalVectorLine([[.075,-.075],[.29,-.29]]));
        }else if(type==='menu'){
          icon.add(orbitalVectorLine([[-.27,.19],[.27,.19]]));
          icon.add(orbitalVectorLine([[-.27,0],[.27,0]]));
          icon.add(orbitalVectorLine([[-.27,-.19],[.27,-.19]]));
        }else if(type==='music-off'){
          icon.add(orbitalVectorLine([[-.28,-.11],[-.12,-.11],[.02,-.25],[.02,.25],[-.12,.11],[-.28,.11]],true));
          icon.add(orbitalVectorLine([[-.29,-.29],[.29,.29]]));
        }
        return icon;
      }
      for(let i=0;i<ORBITAL_SQUARE_COUNT;i++){
        const group=new THREE.Group();
        const fill=new THREE.Mesh(orbitalSquareGeometry,orbitalSquareGlassMaterial);
        const edge=new THREE.LineSegments(orbitalSquareEdgeGeometry,orbitalSquareEdgeMaterial);
        edge.position.z=.002;
        fill.renderOrder=50000; edge.renderOrder=50001;
        const action=orbitalButtonActions[i]||null;
        const icon=action?buildOrbitalVectorIcon(action):null;
        const hitMaterial=new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthTest:false,depthWrite:false});
        const hit=new THREE.Mesh(orbitalSquareGeometry,hitMaterial);
        hit.scale.setScalar(1.34); hit.position.z=.03; hit.renderOrder=50002;
        group.renderOrder=49999;
        group.add(fill,edge,hit); if(icon) group.add(icon);
        fill.userData.orbitalSquareOwner=group;
        edge.userData.orbitalSquareOwner=group;
        hit.userData.orbitalSquareOwner=group;
        group.userData.hitTarget=hit;
        group.userData.orbitIndex=i;
        group.userData.action=action;
        group.userData.buttonId=action||`future-button-${i+1}`;
        group.userData.hoverMix=0;
        group.userData.pressUntil=0;
        group.userData.baseScale=1;
        group.userData.sizeFactor=orbitalSquareSizeFactors[i];
        group.userData.baseAngle=(-Math.PI*.96)+(Math.PI*2)*(i/ORBITAL_SQUARE_COUNT);
        group.userData.angleOffset=0;
        group.userData.radialScale=1;
        group.visible=false;
        orbitalSquares.push(group);
        scene.add(group);
      }
      let orbitalPhase=0;
      let orbitalWasMoving=false;
      let orbitalLayoutInitialized=false;

      const raycaster=new THREE.Raycaster();
      const pointerNdc=new THREE.Vector2(2,2);
      let pointerActive=false,hoveredCard=null,hoveredSquare=null,heroCard=null;
      let grabbedCard=null,grabPointerId=null,grabMoved=false,suppressNextClick=false;
      const grabStartClient=new THREE.Vector2();
      const grabPlane=new THREE.Plane(new THREE.Vector3(0,0,1),0);
      const grabPointerWorld=new THREE.Vector3();
      const grabTargetWorld=new THREE.Vector3();
      const grabOffsetWorld=new THREE.Vector3();
      let heroFlipTarget=0,heroFlipCurrent=0;
      let sequenceDirection=1;
      let supportBiasDirection=1;
      let lastInputAt=-Infinity;
      let lastGestureEventAt=-Infinity;
      let settleSnapDone=true;
      let retainedVisibleCount=INITIAL_GROUP_SIZE;
      let gestureVisibleCount=INITIAL_GROUP_SIZE;
      let gestureEnergy=0;
      // Logical group state is deliberately independent of camera/path distance.
      let logicalGroupStart=1;
      let logicalGroupSize=INITIAL_GROUP_SIZE;
      let logicalGroupDirection=1;
      let groupGestureActive=false;
      let groupGestureEnergy=0;
      let groupGestureSignedDelta=0;
      let groupGestureLastAt=-Infinity;
      let groupGestureNextSize=INITIAL_GROUP_SIZE;
      let flipOwnerSequenceStep=null;
      let lastPublishedStateSignature='';
      let navigationActive=false;
      let navigationTargetStep=null;
      let navigationTargetSequence=null;
      let navigationTargetAnchor=null;
      let navigationSource=null;
      let navigationStartedAt=-Infinity;
      let navigationUpdateHistory=true;
      let navigationExpectedDuration=PROGRAMMATIC_MIN_DURATION;
      let manualGestureActive=false;
      let manualGestureOriginStep=0;
      let manualGestureTargetStep=0;
      let manualGestureDirection=1;
      let manualImpulseEnergy=0;
      let manualImpulseDirection=0;
      let lastManualImpulseAt=-Infinity;
      let lastManualAcceptedStepAt=-Infinity;

      function setPointerFromEvent(event){pointerNdc.x=(event.clientX/innerWidth)*2-1;pointerNdc.y=-(event.clientY/innerHeight)*2+1}
      function updateGrabTargetFromPointer(){
        if(!grabbedCard) return false;
        raycaster.setFromCamera(pointerNdc,camera);
        grabPlane.set(new THREE.Vector3(0,0,1),-grabbedCard.userData.basePosition.z);
        if(!raycaster.ray.intersectPlane(grabPlane,grabPointerWorld)) return false;
        grabTargetWorld.copy(grabPointerWorld).add(grabOffsetWorld);
        return true;
      }
      addEventListener('pointermove',e=>{
        setPointerFromEvent(e);pointerActive=true;
        if(grabbedCard && e.pointerId===grabPointerId){
          const dx=e.clientX-grabStartClient.x,dy=e.clientY-grabStartClient.y;
          if(Math.hypot(dx,dy)>=GRAB_MOVE_THRESHOLD_PX) grabMoved=true;
          updateGrabTargetFromPointer();
          e.preventDefault();
        }
      },{passive:false});
      addEventListener('pointerleave',()=>{if(!grabbedCard){pointerActive=false;hoveredCard=null;hoveredSquare=null;renderer.domElement.style.cursor='default'}});

      const camProxy={t:0};
      const setCamT=gsap.quickTo(camProxy,'t',{duration:1,ease:'power3.out'});
      let cameraTween=null;
      function tweenCamT(nextT,duration){
        if(cameraTween) cameraTween.kill();
        cameraTween=gsap.to(camProxy,{t:nextT,duration,ease:'power3.out',overwrite:'auto',onComplete:()=>{cameraTween=null;}});
      }
      function programmaticDurationForStep(step){
        const cards=Math.abs(step-currentSequenceCoord());
        return THREE.MathUtils.clamp(PROGRAMMATIC_MIN_DURATION+cards*PROGRAMMATIC_SECONDS_PER_CARD,PROGRAMMATIC_MIN_DURATION,PROGRAMMATIC_MAX_DURATION);
      }
      let targetT=0;

      // Pure sequence state for the standalone carousel.
      function normalizedSequenceNumber(sequenceNumber){
        return THREE.MathUtils.clamp(Math.round(Number(sequenceNumber)||1),1,ORIGINAL_SEQUENCE_TOTAL);
      }
      function contentSequenceFor(sequenceNumber){
        return normalizedSequenceNumber(sequenceNumber);
      }
      function nearestUnwrappedStepForSequence(sequenceNumber){
        const n=normalizedSequenceNumber(sequenceNumber);
        const base=n-1;
        const coord=currentSequenceCoord();
        return base+Math.round((coord-base)/ORIGINAL_SEQUENCE_TOTAL)*ORIGINAL_SEQUENCE_TOTAL;
      }
      function buildPublicSceneState(){
        const visible=activeCards
          .filter(card=>card.visible && (card.userData.presence??0)>.08)
          .sort((a,b)=>b.renderOrder-a.renderOrder)
          .map(card=>({
            sequenceNumber:card.userData.sequenceNumber,
            sequenceStep:card.userData.sequenceStep,
            isHero:card===heroCard,
            layer:card===heroCard?1:(card.renderOrder>=SUPPORT_SECOND_RENDER_ORDER?2:3)
          }));
        return {
          version:'carousel-core-pure-1',
          activeSequence:heroCard?.userData.sequenceNumber||1,
          activeSequenceStep:heroCard?.userData.sequenceStep||0,
          visibleActiveCount:visible.length,
          sequenceDirection,
          heroFlipped:heroFlipTarget>Math.PI*.5,
          inputActive:performance.now()-lastInputAt<=SETTLE_DELAY_MS,
          navigationActive,
          logicalGroupStart,
          logicalGroupSize,
          logicalGroupDirection,
          visible
        };
      }
      function publishSceneState(){
        const detail=buildPublicSceneState();
        const signature=[
          detail.activeSequence,detail.visibleActiveCount,detail.sequenceDirection,
          detail.heroFlipped,detail.inputActive,detail.navigationActive
        ].join('|');
        if(signature===lastPublishedStateSignature) return;
        lastPublishedStateSignature=signature;
        window.dispatchEvent(new CustomEvent('aiultra:scene-state',{detail}));
      }
      window.AIUltraScene=Object.freeze({
        version:'carousel-core-pure-1',
        getState:()=>buildPublicSceneState(),
        goToSequence:(sequenceNumber,options={})=>navigateToSequence(
          sequenceNumber,{source:options.source||'api'}
        ),
        eventName:'aiultra:scene-state',
        navigationStartEvent:'aiultra:navigation-start',
        navigationEndEvent:'aiultra:navigation-end'
      });

      function visibleWorldHeight(distance){return 2*distance*Math.tan(THREE.MathUtils.degToRad(camera.fov*.5))}
      function sequenceNumberFromStep(step){return mod(step,ORIGINAL_SEQUENCE_TOTAL)+1}
      function cardTFromStep(step){return wrap01(step/ORIGINAL_SEQUENCE_TOTAL)}
      function currentSequenceCoord(){return -camProxy.t*ORIGINAL_SEQUENCE_TOTAL}

      function queueManualStep(direction,now){
        const dir=direction>=0?1:-1;
        const baseStep=manualGestureActive
          ? manualGestureTargetStep
          : (heroCard?.userData.sequenceStep??Math.round(currentSequenceCoord()));
        if(!manualGestureActive) manualGestureOriginStep=baseStep;
        manualGestureDirection=dir;
        manualGestureTargetStep=baseStep+dir;
        manualGestureActive=true;
        sequenceDirection=dir;
        supportBiasDirection=dir;
        targetT=-manualGestureTargetStep/ORIGINAL_SEQUENCE_TOTAL;
        settleSnapDone=false;
        tweenCamT(targetT,MANUAL_STEP_DURATION);
        lastInputAt=now;
      }

      function registerManualImpulse(deltaY,now,inputType='wheel'){
        const dir=deltaY>=0?1:-1;
        const isWheel=inputType==='wheel';
        lastInputAt=now;

        // Desktop wheel: no energy gate. A real wheel impulse starts immediately. The short
        // refractory window only collapses duplicate browser events from the same physical notch.
        if(isWheel){
          if(manualImpulseDirection!==0 && dir!==manualImpulseDirection){
            manualImpulseEnergy=0;
          }
          manualImpulseDirection=dir;
          lastManualImpulseAt=now;
          if(now-lastManualAcceptedStepAt<MANUAL_WHEEL_REFRACTORY_MS) return false;
          lastManualAcceptedStepAt=now;
          queueManualStep(dir,now);
          return true;
        }

        // Touch/pointer drag still aggregates tiny movement so one finger drag does not enqueue
        // dozens of logical cards. This path does not affect desktop mouse-wheel responsiveness.
        const idle=now-lastManualImpulseAt>MANUAL_TOUCH_IDLE_MS;
        if(idle || (manualImpulseDirection!==0 && dir!==manualImpulseDirection)){
          manualImpulseEnergy=0;
          manualImpulseDirection=dir;
        }
        manualImpulseDirection=dir;
        manualImpulseEnergy+=Math.min(Math.abs(deltaY),MANUAL_IMPULSE_EVENT_CAP);
        lastManualImpulseAt=now;
        if(manualImpulseEnergy<MANUAL_TOUCH_STEP_ENERGY) return false;
        manualImpulseEnergy=0;
        lastManualAcceptedStepAt=now;
        queueManualStep(dir,now);
        return true;
      }

      function cancelManualGesture(){
        manualGestureActive=false;
        manualGestureOriginStep=Math.round(currentSequenceCoord());
        manualGestureTargetStep=manualGestureOriginStep;
        manualImpulseEnergy=0;
        manualImpulseDirection=0;
      }

      function wrapSequenceNumber(value){ return mod(Math.round(value)-1,ORIGINAL_SEQUENCE_TOTAL)+1; }
      function groupSizeFromGestureEnergy(energy){
        let count=MIN_VISIBLE_ACTIVE;
        for(const threshold of GROUP_SIZE_THRESHOLDS) if(energy>=threshold) count+=1;
        return THREE.MathUtils.clamp(count,MIN_VISIBLE_ACTIVE,MAX_VISIBLE_ACTIVE);
      }
      function registerLogicalGroupGesture(deltaY,now){
        // New physical wheel session: numbering stays frozen until the camera has actually come to rest.
        if(!groupGestureActive || now-groupGestureLastAt>GROUP_GESTURE_GAP_MS){
          groupGestureActive=true;
          groupGestureEnergy=0;
          groupGestureSignedDelta=0;
          groupGestureNextSize=MIN_VISIBLE_ACTIVE;
        }
        groupGestureEnergy+=Math.min(Math.abs(deltaY),ACTIVE_REVEAL_EVENT_CAP);
        groupGestureSignedDelta+=deltaY;
        groupGestureNextSize=groupSizeFromGestureEnergy(groupGestureEnergy);
        groupGestureLastAt=now;
      }
      function commitLogicalGroupIfStopped(now){
        if(!groupGestureActive || navigationActive || grabbedCard) return false;
        if(now-groupGestureLastAt<=GROUP_GESTURE_GAP_MS) return false;
        const visuallyStopped=Math.abs(camProxy.t-targetT)<=GROUP_VISUAL_STOP_EPSILON;
        // Never advance funnel content while the original Pass 4 camera is still easing.
        if(!visuallyStopped) return false;
        const dir=groupGestureSignedDelta===0?sequenceDirection:(groupGestureSignedDelta>0?1:-1);
        // FUNNEL CONTRACT: visual distance never decides content order. One fully settled scroll session
        // moves the logical hero by exactly one card. The physical camera is never snapped or rewound.
        // Ring semantics: content order is circular even though one settled gesture still advances exactly one card.
        // Down: 1→2→3…→500→1. Up: 1→500→499…→2→1.
        logicalGroupStart=wrapSequenceNumber(logicalGroupStart + dir);
        logicalGroupDirection=dir;
        // Visible-card count remains a visual-only property of the original V35 gesture. It does not affect numbering.
        logicalGroupSize=THREE.MathUtils.clamp(groupGestureNextSize,MIN_VISIBLE_ACTIVE,MAX_VISIBLE_ACTIVE);
        retainedVisibleCount=logicalGroupSize;
        gestureVisibleCount=logicalGroupSize;
        gestureEnergy=0;
        groupGestureActive=false;
        supportBiasDirection=dir;
        sequenceDirection=dir;
        heroFlipTarget=0; heroFlipCurrent=0; flipOwnerSequenceStep=null;
        return true;
      }

      function desiredStepsFor(coord){
        // Seven physical slots only provide room for a logical group of 1..7.
        // Their identity/number is assigned separately from the physical path step.
        const center=Math.round(coord);
        return [center-3,center-2,center-1,center,center+1,center+2,center+3];
      }

      function ensureAssignments(coord){
        const desired=desiredStepsFor(coord);
        const desiredSet=new Set(desired);
        const byStep=new Map();
        for(const card of activeCards) if(card.userData.sequenceStep!==null) byStep.set(card.userData.sequenceStep,card);
        const free=activeCards.filter(card=>card.userData.sequenceStep===null || !desiredSet.has(card.userData.sequenceStep));
        for(const step of desired){
          if(byStep.has(step)) continue;
          const card=free.shift();
          card.userData.sequenceStep=step;
          card.userData.sequenceNumber=card.userData.sequenceNumber||1;
          card.userData.hoverMix=0;
          card.userData.visibilityMix=0;
          card.userData.laneInitialized=false;
          card.rotation.set(0,0,0);
        }
        for(const card of activeCards){
          card.visible=desiredSet.has(card.userData.sequenceStep);
        }
      }

      function setCardRenderOrder(card,order){
        card.renderOrder=order;
        if(card.children[0]) card.children[0].renderOrder=order+1;
        if(card.userData.backFace) card.userData.backFace.renderOrder=order+2;
        if(card.userData.edgeGlow) card.userData.edgeGlow.renderOrder=order+3;
      }

      function pickTopVisibleCard(){
        raycaster.setFromCamera(pointerNdc,camera);
        const candidates=activeCards.filter(c=>c.visible && (c.userData.presence??1)>.08);
        // Raster cards render FrontSide, but a flipped hero still has to be clickable from its back
        // so a second click can always return it face-on. Temporarily relax raycast culling only.
        const restored=[];
        for(const card of candidates){
          if(card.material && card.material.side===THREE.FrontSide){restored.push(card.material);card.material.side=THREE.DoubleSide;}
        }
        const hits=raycaster.intersectObjects(candidates,false);
        for(const material of restored) material.side=THREE.FrontSide;
        if(!hits.length) return null;
        // Renderer order is the visual truth in this scene. Prefer the top painted card first;
        // use physical hit distance only as a tie-breaker inside the same visual layer.
        hits.sort((a,b)=>(b.object.renderOrder-a.object.renderOrder)||(a.distance-b.distance));
        return hits[0].object;
      }

      function supportLaneForOffset(offset){
        // V33 lanes are untouched for +/-1 and +/-2. Two extra small outer slots are added only for 6/7-card groups.
        if(offset===-1) return {x:-SIDE_LANE_X_NDC,y: SIDE_LANE_Y_NDC*.72,z:SIDE_LANE_DEPTH*.92,layer:2};
        if(offset=== 1) return {x: SIDE_LANE_X_NDC,y:-SIDE_LANE_Y_NDC,z:SIDE_LANE_DEPTH*.78,layer:2};
        if(offset===-2) return {x:-SIDE_LANE_X_FAR_NDC,y:-SIDE_LANE_Y_FAR_NDC,z:SIDE_LANE_DEPTH*1.42,layer:3};
        if(offset=== 2) return {x: SIDE_LANE_X_FAR_NDC,y: SIDE_LANE_Y_FAR_NDC,z:SIDE_LANE_DEPTH*1.28,layer:3};
        if(offset<=-3) return {x:-.60,y:.31,z:SIDE_LANE_DEPTH*1.88,layer:3};
        return {x:.60,y:-.31,z:SIDE_LANE_DEPTH*1.74,layer:3};
      }

      function updateActiveFlow(coord,dt,inputActive){
        ensureAssignments(coord);
        const heroStep=Math.round(coord);
        heroCard=activeCards.find(card=>card.visible && card.userData.sequenceStep===heroStep)||null;

        // Logical group count is frozen for the whole visual scroll and changes only after full stop.
        const visibleCount=THREE.MathUtils.clamp(logicalGroupSize,MIN_VISIBLE_ACTIVE,MAX_VISIBLE_ACTIVE);
        const ranked=[...activeCards].sort((a,b)=>{
          const da=Math.abs(a.userData.sequenceStep-coord),db=Math.abs(b.userData.sequenceStep-coord);
          if(Math.abs(da-db)>1e-7) return da-db;
          // When two cards are equally close, prefer the current scroll direction.
          const aa=(a.userData.sequenceStep-heroStep)*supportBiasDirection>=0?0:1;
          const bb=(b.userData.sequenceStep-heroStep)*supportBiasDirection>=0?0:1;
          return aa-bb;
        });
        const activeSet=new Set(ranked.slice(0,visibleCount));
        // Hero is always the frozen/current funnel number. Supports follow sequentially in the current
        // reading direction and wrap across the 500↔1 seam.
        for(let i=0;i<ranked.length;i++){
          ranked[i].userData.sequenceNumber=wrapSequenceNumber(
            logicalGroupStart + logicalGroupDirection*i
          );
        }

        // The hero is the exact nearest physical step. At the half-way handoff boundary,
        // the next hero wins deterministically instead of depending on mesh-array order.
        for(const card of activeCards){
          if(!card.visible) continue;
          const step=card.userData.sequenceStep;
          // Raster removed: every interactive foreground card uses the native glass material.
          if(card.material!==overlayGlass) card.material=overlayGlass;
          if(card.children[0]) card.children[0].visible=true;
          if(card.userData.edgeGlow){
            card.userData.edgeGlow.visible=true;
            card.userData.edgeGlow.material=card===heroCard?bloomEdgeHeroMaterial:bloomEdgeSupportMaterial;
          }
          const distCards=Math.abs(step-coord);
          const cardT=cardTFromStep(step);
          const {pos,nx,ny}=curveFrame(curve,cardT);

          // Preserve a small piece of the source Pass 4 local-normal spread, then add
          // a camera-screen side lane for the four support cards. The lane strength grows
          // naturally as the card leaves the face position, so scroll motion remains fluid.
          const separation=THREE.MathUtils.clamp(distCards,0,1);
          const signedLateral=(hash01(step*17.37+4.21)*2-1)*ACTIVE_LATERAL_MAX*.28;
          const nativeDepth=(hash01(step*29.11+8.73)*2-1)*ACTIVE_DEPTH_MAX*.34;

          let px=pos.x+nx*signedLateral*separation;
          let py=pos.y+ny*signedLateral*separation;
          let pz=pos.z+nativeDepth*separation;

          let laneTargetX=0,laneTargetY=0,laneTargetZ=0,layer=1;
          if(card!==heroCard){
            const lane=supportLaneForOffset(step-heroStep);
            const laneMix=THREE.MathUtils.smoothstep(distCards,.16,1.10);
            laneTargetX=lane.x*laneMix;
            laneTargetY=lane.y*laneMix;
            laneTargetZ=lane.z*laneMix;
            layer=lane.layer;
          }

          // The important V25 fix: lane changes are stateful. When hero ownership changes
          // during the last part of a scroll, cards glide to their new side/center lane
          // instead of receiving an instantaneous offset and visually jumping.
          if(!card.userData.laneInitialized){
            card.userData.laneX=laneTargetX;
            card.userData.laneY=laneTargetY;
            card.userData.laneZ=laneTargetZ;
            card.userData.laneInitialized=true;
          }else{
            const laneDamp=inputActive?SUPPORT_LANE_DAMP_MOVING:SUPPORT_LANE_DAMP_SETTLE;
            const laneA=1-Math.exp(-laneDamp*dt);
            card.userData.laneX=THREE.MathUtils.lerp(card.userData.laneX,laneTargetX,laneA);
            card.userData.laneY=THREE.MathUtils.lerp(card.userData.laneY,laneTargetY,laneA);
            card.userData.laneZ=THREE.MathUtils.lerp(card.userData.laneZ,laneTargetZ,laneA);
            if(!inputActive){
              if(Math.abs(card.userData.laneX-laneTargetX)<.00015) card.userData.laneX=laneTargetX;
              if(Math.abs(card.userData.laneY-laneTargetY)<.00015) card.userData.laneY=laneTargetY;
              if(Math.abs(card.userData.laneZ-laneTargetZ)<.00015) card.userData.laneZ=laneTargetZ;
            }
          }

          if(card.userData.laneX||card.userData.laneY||card.userData.laneZ){
            const cameraDistance=Math.max(.75,camera.position.z-pz);
            const visibleH=visibleWorldHeight(cameraDistance);
            const visibleW=visibleH*camera.aspect;
            px+=card.userData.laneX*(visibleW*.5);
            py+=card.userData.laneY*(visibleH*.5);
            pz-=card.userData.laneZ;
          }

          card.userData.basePosition.set(px,py,pz);
          card.position.copy(card.userData.basePosition);

          const cameraDistance=Math.max(.75,camera.position.z-card.position.z);
          const visibleH=visibleWorldHeight(cameraDistance);
          const focus=THREE.MathUtils.clamp(1-distCards/ACTIVE_FOCUS_RADIUS_CARDS,0,1);
          const recyclePresence=1-THREE.MathUtils.smoothstep(distCards,ACTIVE_RECYCLE_FADE_START,ACTIVE_RECYCLE_FADE_END);
          const visibilityTarget=(card===heroCard || activeSet.has(card))?1:0;
          const visibilityA=1-Math.exp(-ACTIVE_VISIBILITY_DAMP*dt);
          card.userData.visibilityMix=THREE.MathUtils.lerp(card.userData.visibilityMix,visibilityTarget,visibilityA);
          if(card===heroCard) card.userData.visibilityMix=1;
          const presence=recyclePresence*card.userData.visibilityMix;
          const screenH=(MIN_ACTIVE_SCREEN_HEIGHT+(HERO_SCREEN_HEIGHT-MIN_ACTIVE_SCREEN_HEIGHT)*Math.pow(focus,1.35))*presence;
          card.userData.baseScale=visibleH*screenH;
          card.userData.presence=presence;
          card.scale.setScalar(card.userData.baseScale);
          // Source-faithful: Pass 4 planes do not self-spin; perceived rotation comes from camera/path motion.
          card.rotation.x=0; card.rotation.z=0; card.rotation.y=0;
          if(card===heroCard) setCardRenderOrder(card,HERO_RENDER_ORDER);
          else setCardRenderOrder(card,layer===2?SUPPORT_SECOND_RENDER_ORDER:SUPPORT_THIRD_RENDER_ORDER);
        }

        if(heroCard) setCardRenderOrder(heroCard,HERO_RENDER_ORDER);
      }

      const orbitalCardCornerLocal=[
        new THREE.Vector3(-CARD_WIDTH*.5,-CARD_HEIGHT*.5,0),
        new THREE.Vector3( CARD_WIDTH*.5,-CARD_HEIGHT*.5,0),
        new THREE.Vector3( CARD_WIDTH*.5, CARD_HEIGHT*.5,0),
        new THREE.Vector3(-CARD_WIDTH*.5, CARD_HEIGHT*.5,0)
      ];
      const orbitalProjectedCorner=new THREE.Vector3();
      const orbitalCandidateWorld=new THREE.Vector3();
      const orbitalCandidateNdc=new THREE.Vector3();
      function ndcRectsOverlap(a,b){
        return a.minX<b.maxX && a.maxX>b.minX && a.minY<b.maxY && a.maxY>b.minY;
      }
      function ndcOverlapArea(a,b){
        const w=Math.max(0,Math.min(a.maxX,b.maxX)-Math.max(a.minX,b.minX));
        const h=Math.max(0,Math.min(a.maxY,b.maxY)-Math.max(a.minY,b.minY));
        return w*h;
      }
      function collectActiveCardNdcRects(){
        const rects=[];
        for(const card of activeCards){
          if(!card.visible || (card.userData.presence??0)<.08) continue;
          card.updateMatrixWorld(true);
          let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,valid=false;
          for(const local of orbitalCardCornerLocal){
            orbitalProjectedCorner.copy(local);
            card.localToWorld(orbitalProjectedCorner);
            orbitalProjectedCorner.project(camera);
            if(!Number.isFinite(orbitalProjectedCorner.x)||!Number.isFinite(orbitalProjectedCorner.y)) continue;
            minX=Math.min(minX,orbitalProjectedCorner.x);
            minY=Math.min(minY,orbitalProjectedCorner.y);
            maxX=Math.max(maxX,orbitalProjectedCorner.x);
            maxY=Math.max(maxY,orbitalProjectedCorner.y);
            valid=true;
          }
          if(!valid) continue;
          rects.push({
            minX:minX-ORBITAL_SQUARE_CARD_CLEARANCE_NDC,
            maxX:maxX+ORBITAL_SQUARE_CARD_CLEARANCE_NDC,
            minY:minY-ORBITAL_SQUARE_CARD_CLEARANCE_NDC,
            maxY:maxY+ORBITAL_SQUARE_CARD_CLEARANCE_NDC
          });
        }
        return rects;
      }
      function updateOrbitalSquares(dt,motionActive){
        if(!heroCard || !heroCard.visible || (heroCard.userData.presence??0)<.08){
          for(const sq of orbitalSquares) sq.visible=false;
          return;
        }

        const TAU=Math.PI*2;
        // V114.1 motion lock: satellites move only while the carousel itself moves.
        // No post-scroll settle arc, no extra lap, no jump after wheel/touch release.
        if(motionActive){
          orbitalPhase+=ORBITAL_SQUARE_ROTATION_SPEED*dt;
          orbitalWasMoving=true;
        }else{
          orbitalWasMoving=false;
          // Freeze the exact last rendered transform once the carousel has stopped.
          // We still allow one initial layout before the first gesture.
          if(orbitalLayoutInitialized) return;
        }

        const heroPos=heroCard.position;
        const depth=Math.max(.75,camera.position.z-heroPos.z);
        const visibleH=visibleWorldHeight(depth);
        const visibleW=visibleH*camera.aspect;
        const phase=mod(orbitalPhase,TAU);
        const blockedRects=collectActiveCardNdcRects();
        const occupiedRects=[];

        for(const sq of orbitalSquares){
          const desiredAngle=sq.userData.baseAngle-phase;
          const s=visibleH*ORBITAL_SQUARE_SCREEN_SIZE*sq.userData.sizeFactor;
          const halfNdcY=(s/visibleH)*1.06;
          const halfNdcX=halfNdcY/Math.max(camera.aspect,.35);
          let chosen=null;
          let bestFallback=null;
          let bestFallbackScore=Infinity;

          for(let search=0;search<=ORBITAL_SQUARE_SEARCH_STEPS;search++){
            const ringIndex=Math.ceil(search*.5);
            const sign=search===0?0:(search%2===1?1:-1);
            const angleOffset=sign*ringIndex*ORBITAL_SQUARE_SEARCH_STEP;
            const angle=desiredAngle+angleOffset;
            for(const radialScale of ORBITAL_SQUARE_RADIAL_LEVELS){
              const x=heroPos.x+Math.cos(angle)*(visibleW*.5*ORBITAL_SQUARE_RADIUS_X_NDC*radialScale);
              const y=heroPos.y+Math.sin(angle)*(visibleH*.5*ORBITAL_SQUARE_RADIUS_Y_NDC*radialScale);
              const z=heroPos.z+.90; // V114.2 future buttons stay in front of glass
              orbitalCandidateWorld.set(x,y,z);
              orbitalCandidateNdc.copy(orbitalCandidateWorld).project(camera);
              if(!Number.isFinite(orbitalCandidateNdc.x)||!Number.isFinite(orbitalCandidateNdc.y)) continue;
              const rect={
                minX:orbitalCandidateNdc.x-halfNdcX,
                maxX:orbitalCandidateNdc.x+halfNdcX,
                minY:orbitalCandidateNdc.y-halfNdcY,
                maxY:orbitalCandidateNdc.y+halfNdcY
              };
              const inside=rect.minX>-1+ORBITAL_SQUARE_EDGE_MARGIN_NDC && rect.maxX<1-ORBITAL_SQUARE_EDGE_MARGIN_NDC &&
                           rect.minY>-1+ORBITAL_SQUARE_EDGE_MARGIN_NDC && rect.maxY<1-ORBITAL_SQUARE_EDGE_MARGIN_NDC;
              let overlap=0;
              for(const blocked of blockedRects) overlap+=ndcOverlapArea(rect,blocked);
              for(const used of occupiedRects) overlap+=ndcOverlapArea(rect,used)*1.35;
              const continuity=Math.abs(angleOffset-(sq.userData.angleOffset||0))*.016+Math.abs(radialScale-(sq.userData.radialScale||1))*.022;
              const score=overlap*1200+(inside?0:20)+continuity+Math.abs(angleOffset)*.002+(radialScale-1)*.004;
              if(score<bestFallbackScore){
                bestFallbackScore=score;
                bestFallback={x,y,z,rect,angleOffset,radialScale};
              }
              if(!inside || overlap>1e-7) continue;
              chosen={x,y,z,rect,angleOffset,radialScale};
              break;
            }
            if(chosen) break;
          }

          const slot=chosen||bestFallback;
          if(!slot){sq.visible=false;continue;}
          sq.userData.angleOffset=slot.angleOffset;
          sq.userData.radialScale=slot.radialScale;
          sq.position.set(slot.x,slot.y,slot.z);
          sq.rotation.set(0,0,0);
          sq.userData.baseScale=s;
          sq.scale.setScalar(s);
          sq.visible=true;
          occupiedRects.push(slot.rect);
        }
        orbitalLayoutInitialized=true;
      }

      function pickTopOrbitalSquare(){
        if(!pointerActive) return null;
        raycaster.setFromCamera(pointerNdc,camera);
        const targets=[];
        for(const sq of orbitalSquares){
          if(!sq.visible) continue;
          const hit=sq.userData.hitTarget||sq.children?.[0];
          if(hit) targets.push(hit);
        }
        const hits=raycaster.intersectObjects(targets,false);
        return hits.length?(hits[0].object.userData.orbitalSquareOwner||hits[0].object.parent||null):null;
      }
      function applyOrbitalSquareHover(dt){
        const a=1-Math.exp(-13.5*dt);
        for(const sq of orbitalSquares){
          const target=sq===hoveredSquare?1:0;
          sq.userData.hoverMix=THREE.MathUtils.lerp(sq.userData.hoverMix||0,target,a);
          const base=sq.userData.baseScale||sq.scale.x||1;
          const pressed=performance.now()<(sq.userData.pressUntil||0);
          sq.scale.setScalar(base*(1+sq.userData.hoverMix*.22)*(pressed?.92:1));
        }
      }
      function updateHoverSelection(){
        if(grabbedCard){hoveredCard=null;hoveredSquare=null;renderer.domElement.style.cursor='grabbing';return}
        if(!pointerActive || manualGestureActive || navigationActive || performance.now()-lastInputAt<SETTLE_DELAY_MS){hoveredCard=null;hoveredSquare=null;renderer.domElement.style.cursor='default';return}
        hoveredSquare=pickTopOrbitalSquare();
        if(hoveredSquare){hoveredCard=null;renderer.domElement.style.cursor='pointer';return}
        hoveredCard=pickTopVisibleCard();
        renderer.domElement.style.cursor=hoveredCard?'grab':'default';
      }

      const hoverProjected=new THREE.Vector3(),hoverWorld=new THREE.Vector3();
      function applyHoverPose(card,dt){
        const shouldGrow=hoveredCard===card && card!==heroCard;
        const target=shouldGrow?1:0;
        const a=1-Math.exp(-HOVER_DAMP*dt);
        card.userData.hoverMix=THREE.MathUtils.lerp(card.userData.hoverMix,target,a);
        const m=card.userData.hoverMix;
        if(m<.001){
          card.position.copy(card.userData.basePosition);card.scale.setScalar(card.userData.baseScale);
          if(card!==heroCard){
            const offset=card.userData.sequenceStep-Math.round(currentSequenceCoord());
            const lane=supportLaneForOffset(offset);
            setCardRenderOrder(card,lane.layer===2?SUPPORT_SECOND_RENDER_ORDER:SUPPORT_THIRD_RENDER_ORDER);
          }
          return;
        }

        const basePosition=card.userData.basePosition,baseScale=card.userData.baseScale;
        const depth=Math.max(.75,camera.position.z-basePosition.z);
        const visibleH=visibleWorldHeight(depth),visibleW=visibleH*camera.aspect;
        const targetScreenH=Math.min(HERO_SCREEN_HEIGHT,(1-HOVER_VIEWPORT_MARGIN_NDC)*camera.aspect/CARD_WIDTH);
        const halfW=(targetScreenH*CARD_WIDTH)/camera.aspect,halfH=targetScreenH;
        hoverProjected.copy(basePosition).project(camera);
        let tx=THREE.MathUtils.clamp(hoverProjected.x,-1+halfW+HOVER_VIEWPORT_MARGIN_NDC,1-halfW-HOVER_VIEWPORT_MARGIN_NDC);
        let ty=THREE.MathUtils.clamp(hoverProjected.y,-1+halfH+HOVER_VIEWPORT_MARGIN_NDC,1-halfH-HOVER_VIEWPORT_MARGIN_NDC);
        hoverWorld.set(camera.position.x+tx*(visibleW*.5),camera.position.y+ty*(visibleH*.5),basePosition.z);
        card.position.lerpVectors(basePosition,hoverWorld,m);
        card.scale.setScalar(THREE.MathUtils.lerp(baseScale,visibleH*targetScreenH,m));
        setCardRenderOrder(card,HOVER_RENDER_ORDER);
      }

      const grabProjected=new THREE.Vector3(),grabClampedWorld=new THREE.Vector3();
      function applyGrabPose(card,dt){
        const target=grabbedCard===card?1:0;
        const damp=target?GRAB_DAMP:GRAB_RELEASE_DAMP;
        const a=1-Math.exp(-damp*dt);
        card.userData.grabMix=THREE.MathUtils.lerp(card.userData.grabMix,target,a);
        const m=card.userData.grabMix;
        if(m<.001){card.userData.grabMix=0;return;}

        const basePosition=card.position.clone();
        const baseScale=card.scale.x;
        const depth=Math.max(.75,camera.position.z-card.userData.basePosition.z);
        const visibleH=visibleWorldHeight(depth),visibleW=visibleH*camera.aspect;
        const targetScale=visibleH*HERO_SCREEN_HEIGHT;
        const targetScreenH=HERO_SCREEN_HEIGHT;
        const halfW=(targetScreenH*CARD_WIDTH)/camera.aspect,halfH=targetScreenH;

        const requested=(grabbedCard===card?grabTargetWorld:card.userData.basePosition);
        grabProjected.copy(requested).project(camera);
        const tx=THREE.MathUtils.clamp(grabProjected.x,-1+halfW+GRAB_VIEWPORT_MARGIN_NDC,1-halfW-GRAB_VIEWPORT_MARGIN_NDC);
        const ty=THREE.MathUtils.clamp(grabProjected.y,-1+halfH+GRAB_VIEWPORT_MARGIN_NDC,1-halfH-GRAB_VIEWPORT_MARGIN_NDC);
        grabClampedWorld.set(camera.position.x+tx*(visibleW*.5),camera.position.y+ty*(visibleH*.5),card.userData.basePosition.z);

        if(grabbedCard===card){
          card.position.lerpVectors(basePosition,grabClampedWorld,m);
          card.scale.setScalar(THREE.MathUtils.lerp(baseScale,targetScale,m));
          setCardRenderOrder(card,GRAB_RENDER_ORDER);
        }else{
          card.position.lerpVectors(card.userData.basePosition,basePosition,m);
          card.scale.setScalar(THREE.MathUtils.lerp(card.userData.baseScale,baseScale,m));
        }
      }

      const labelPoint=new THREE.Vector3(),labelLocal=new THREE.Vector3();
      const heroCornerLocal=[
        new THREE.Vector3(-CARD_WIDTH*.5,-CARD_HEIGHT*.5,0),
        new THREE.Vector3( CARD_WIDTH*.5,-CARD_HEIGHT*.5,0),
        new THREE.Vector3( CARD_WIDTH*.5, CARD_HEIGHT*.5,0),
        new THREE.Vector3(-CARD_WIDTH*.5, CARD_HEIGHT*.5,0)
      ];
      const heroCornerWorld=new THREE.Vector3();
      const heroNdcBounds={minX:0,maxX:0,minY:0,maxY:0,valid:false};
      function updateHeroNdcBounds(){
        heroNdcBounds.valid=false;
        if(!heroCard || !heroCard.visible || (heroCard.userData.presence??1)<.08) return;
        heroCard.updateMatrixWorld(true);
        let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
        for(const corner of heroCornerLocal){
          heroCornerWorld.copy(corner);heroCard.localToWorld(heroCornerWorld);heroCornerWorld.project(camera);
          minX=Math.min(minX,heroCornerWorld.x);maxX=Math.max(maxX,heroCornerWorld.x);
          minY=Math.min(minY,heroCornerWorld.y);maxY=Math.max(maxY,heroCornerWorld.y);
        }
        heroNdcBounds.minX=minX;heroNdcBounds.maxX=maxX;heroNdcBounds.minY=minY;heroNdcBounds.maxY=maxY;heroNdcBounds.valid=true;
      }
      function updateNumberLabel(card){
        const label=card.userData.label;
        if(!card.visible || (card.userData.presence??1)<.08){label.style.display='none';return}
        const isFlipped=card===heroCard && Math.cos(heroFlipCurrent)<0;
        const localX=(isFlipped?1:-1)*(CARD_WIDTH*.5-CARD_NUMBER_PAD_X);
        labelLocal.set(localX,CARD_HEIGHT*.5-CARD_NUMBER_PAD_Y,.004);
        card.updateMatrixWorld(true); labelPoint.copy(labelLocal); card.localToWorld(labelPoint); labelPoint.project(camera);
        if(labelPoint.z<-1||labelPoint.z>1){label.style.display='none';return}
        // Every visible card keeps its own visible number, even during overlap.
        label.textContent=String(contentSequenceFor(card.userData.sequenceNumber)); label.style.display='block';
        label.classList.toggle('is-hero',card===heroCard);
        label.style.zIndex=String(card===heroCard?8300:(card.renderOrder>=SUPPORT_SECOND_RENDER_ORDER?8200:8100));
        label.style.transform=`translate(${Math.round((labelPoint.x*.5+.5)*innerWidth)}px,${Math.round((-labelPoint.y*.5+.5)*innerHeight)}px)`;
      }

      function moveCameraToStep(step){
        cancelManualGesture();
        heroFlipTarget=0; hoveredCard=null; hoveredSquare=null;
        targetT=-step/ORIGINAL_SEQUENCE_TOTAL;
        lastInputAt=performance.now(); settleSnapDone=true;
        tweenCamT(targetT,MANUAL_STEP_DURATION);
      }

      function navigateToSequence(sequenceNumber,{source='api'}={}){
        cancelManualGesture();
        const normalized=normalizedSequenceNumber(sequenceNumber);
        logicalGroupStart=normalized;
        const step=nearestUnwrappedStepForSequence(normalized);
        sequenceDirection=step>=currentSequenceCoord()?1:-1;
        supportBiasDirection=sequenceDirection;
        navigationActive=true;
        navigationTargetStep=step;
        navigationTargetSequence=normalized;
        navigationTargetAnchor=null;
        navigationSource=source;
        navigationStartedAt=performance.now();
        heroFlipTarget=0;heroFlipCurrent=0;flipOwnerSequenceStep=null;hoveredCard=null;
        targetT=-step/ORIGINAL_SEQUENCE_TOTAL;
        lastInputAt=performance.now();
        settleSnapDone=true;
        navigationExpectedDuration=programmaticDurationForStep(step);
        tweenCamT(targetT,navigationExpectedDuration);
        window.dispatchEvent(new CustomEvent('aiultra:navigation-start',{
          detail:{sequenceNumber:normalized,sequenceStep:step,source}
        }));
        return true;
      }

      function finishNavigation(){
        if(!navigationActive) return;
        camProxy.t=-navigationTargetStep/ORIGINAL_SEQUENCE_TOTAL;
        targetT=camProxy.t;
        lastInputAt=performance.now()-SETTLE_DELAY_MS-1;
        settleSnapDone=true;
        const detail={
          sequenceNumber:navigationTargetSequence,
          sequenceStep:navigationTargetStep,
          source:navigationSource
        };
        navigationActive=false;
        window.dispatchEvent(new CustomEvent('aiultra:navigation-end',{detail}));
        navigationTargetStep=null;navigationTargetSequence=null;navigationTargetAnchor=null;navigationSource=null;
      }

      renderer.domElement.addEventListener('pointerdown',event=>{
        if(event.pointerType!=='mouse' || event.button!==0 || navigationActive) return;
        setPointerFromEvent(event);pointerActive=true;
        const card=pickTopVisibleCard();
        if(!card) return;
        // A flipped hero remains click-to-return; only face-on cards enter grab/play mode.
        if(card===heroCard && Math.cos(heroFlipCurrent)<0) return;
        grabbedCard=card;
        grabPointerId=event.pointerId;
        grabMoved=false;
        grabStartClient.set(event.clientX,event.clientY);
        hoveredCard=null;
        heroFlipTarget=0;
        renderer.domElement.style.cursor='grabbing';
        try{renderer.domElement.setPointerCapture(event.pointerId)}catch(_){}
        raycaster.setFromCamera(pointerNdc,camera);
        grabPlane.set(new THREE.Vector3(0,0,1),-card.userData.basePosition.z);
        if(raycaster.ray.intersectPlane(grabPlane,grabPointerWorld)){
          grabOffsetWorld.copy(card.position).sub(grabPointerWorld);
          grabTargetWorld.copy(card.position);
        }else{
          grabOffsetWorld.set(0,0,0);
          grabTargetWorld.copy(card.position);
        }
        event.preventDefault();
      },{passive:false});

      function releaseGrab(event){
        if(!grabbedCard || (event && event.pointerId!==grabPointerId)) return;
        if(grabMoved) suppressNextClick=true;
        grabbedCard=null;
        grabPointerId=null;
        renderer.domElement.style.cursor='grab';
        if(event){try{renderer.domElement.releasePointerCapture(event.pointerId)}catch(_){}}
      }
      renderer.domElement.addEventListener('pointerup',releaseGrab);
      renderer.domElement.addEventListener('pointercancel',releaseGrab);

      renderer.domElement.addEventListener('click',event=>{
        if(suppressNextClick){suppressNextClick=false;event.preventDefault();return;}
        setPointerFromEvent(event);pointerActive=true;
        const square=pickTopOrbitalSquare();
        if(square){
          square.userData.pressUntil=performance.now()+140;
          const action=square.userData.action||null;
          if(action==='search') window.dispatchEvent(new CustomEvent('aiultra:search-request'));
          else if(action==='menu') window.dispatchEvent(new CustomEvent('aiultra:menu-request'));
          else if(action==='music-off'){
            const muted=document.body.dataset.musicMuted!=='true';
            document.body.dataset.musicMuted=String(muted);
            window.dispatchEvent(new CustomEvent('aiultra:music-toggle',{detail:{muted}}));
          }
          window.dispatchEvent(new CustomEvent('aiultra:satellite-click',{
            detail:{buttonId:square.userData.buttonId,action,index:square.userData.orbitIndex+1}
          }));
          return;
        }
        const card=pickTopVisibleCard();
        if(!card) return;
        if(card===heroCard){
          // Reliable two-way flip: front -> back -> front, including raster hero cards.
          heroFlipTarget=heroFlipTarget>Math.PI*.5?0:Math.PI;
        }else{
          // A short click promotes a support card and its LOGICAL number becomes the new group hero.
          logicalGroupStart=card.userData.sequenceNumber;
          sequenceDirection=card.userData.sequenceStep>=currentSequenceCoord()?1:-1;
          logicalGroupDirection=sequenceDirection;
          moveCameraToStep(card.userData.sequenceStep);
        }
      });

      Observer.create({
        target:window,type:'wheel,touch',
        onChange:self=>{
          if(navigationActive || grabbedCard) return;
          if(Math.abs(self.deltaY)<.01) return;
          heroFlipTarget=0; hoveredCard=null; hoveredSquare=null;
          const inputNow=performance.now();
          lastInputAt=inputNow;
          sequenceDirection=self.deltaY>=0?1:-1;
          supportBiasDirection=sequenceDirection;
          registerLogicalGroupGesture(self.deltaY,inputNow);
          // Source Pass 4 behavior: wheel/touch delta directly moves the path target.
          // No one-card queue, no energy gate, no refractory lock, no forced snap.
          if(cameraTween){cameraTween.kill();cameraTween=null;}
          targetT-=self.deltaY*SENSITIVITY;
          setCamT(targetT);
          settleSnapDone=true;
        }
      });

      let previousFrame=performance.now();
      function animate(now=performance.now()){
        requestAnimationFrame(animate);
        const dt=Math.min((now-previousFrame)/1000,.05); previousFrame=now;
        const flowOffsetT=wrap01(now*0.001*FLOW_CLOCKWISE_SPEED);
        updateFlowInstances(flowOffsetT);
        // Blue flow squares are scroll-coupled, not clock-coupled: when cards stop, squares stop too.
        const orbitalFlowOffsetT=wrap01(camProxy.t);
        if(TINY_ORBITAL_FLOW_ENABLED) updateOrbitalFlowSquares(orbitalFlowOffsetT);
        flowMaterial.uniforms.uOrbitAngle.value=0;

        const t=wrap01(1-camProxy.t);
        const pathPos=curve.getPoint(t);
        camera.position.set(pathPos.x,pathPos.y,pathPos.z+CAM_Z);
        flowMaterial.uniforms.uCurveT.value=t;
        flowMaterial.uniforms.uCameraPos.value.copy(camera.position);
        orbitalFlowSquareMaterial.uniforms.uCurveT.value=t;
        orbitalFlowSquareMaterial.uniforms.uCameraPos.value.copy(camera.position);

        if(navigationActive && navigationTargetStep!==null){
          const arrived=Math.abs(currentSequenceCoord()-navigationTargetStep)<=NAVIGATION_ARRIVAL_EPSILON;
          const timedOut=now-navigationStartedAt>navigationExpectedDuration*1400;
          if(arrived||timedOut) finishNavigation();
        }

        // Input release never invents another destination. Repeated accepted impulses already
        // moved manualGestureTargetStep one adjacent card at a time; settle only freezes support count.
        if(!navigationActive && manualGestureActive && !settleSnapDone && now-lastInputAt>SETTLE_DELAY_MS){
          // Freeze the largest count revealed so far. Already-active supports never disappear
          // merely because the next gesture was short; they keep flowing with the ring.
          retainedVisibleCount=THREE.MathUtils.clamp(
            Math.max(retainedVisibleCount,gestureVisibleCount),
            MIN_VISIBLE_ACTIVE,MAX_VISIBLE_ACTIVE
          );
          gestureVisibleCount=retainedVisibleCount;
          settleSnapDone=true;
        }
        if(!navigationActive && manualGestureActive && now-lastInputAt>SETTLE_DELAY_MS){
          const arrived=Math.abs(currentSequenceCoord()-manualGestureTargetStep)<=MANUAL_GESTURE_ARRIVAL_EPSILON;
          if(arrived){
            camProxy.t=-manualGestureTargetStep/ORIGINAL_SEQUENCE_TOTAL;
            targetT=camProxy.t;
            manualGestureOriginStep=manualGestureTargetStep;
            manualGestureActive=false;
          }
        }

        // Numbering commits only after the original visual tween has actually stopped.
        commitLogicalGroupIfStopped(now);

        const coord=currentSequenceCoord();
        const inputActive=manualGestureActive || navigationActive || now-lastInputAt<=SETTLE_DELAY_MS;
        const carouselMotionActive=navigationActive || Math.abs(camProxy.t-targetT)>GROUP_VISUAL_STOP_EPSILON || now-lastInputAt<=SETTLE_DELAY_MS;
        updateActiveFlow(coord,dt,inputActive);
        updateHoverSelection();
        for(const card of activeCards) if(card.visible) applyHoverPose(card,dt);
        for(const card of activeCards) if(card.visible || card.userData.grabMix>.001) applyGrabPose(card,dt);

        // Hero is always the nearest face card and always the highest layer outside active grab/play mode. The outgoing
        // hero still flies with the flow; dominance transfers only when the next card is nearer.
        if(heroCard){
          const currentHeroStep=heroCard.userData.sequenceStep;
          // Flip belongs to one hero identity only. If scroll hands dominance to the next card
          // before the previous flip has fully settled, the incoming hero always starts face-on.
          if(flipOwnerSequenceStep!==null && currentHeroStep!==flipOwnerSequenceStep){
            heroFlipCurrent=0;
            heroFlipTarget=0;
          }
          flipOwnerSequenceStep=currentHeroStep;
          const a=1-Math.exp(-HERO_FLIP_DAMP*dt);
          heroFlipCurrent=THREE.MathUtils.lerp(heroFlipCurrent,heroFlipTarget,a);
          for(const card of activeCards) if(card.visible && card!==heroCard) card.rotation.y=0;
          heroCard.rotation.y=heroFlipCurrent;
          if(grabbedCard!==heroCard) setCardRenderOrder(heroCard,HERO_RENDER_ORDER);
          if(grabbedCard && grabbedCard!==heroCard) setCardRenderOrder(grabbedCard,GRAB_RENDER_ORDER);
        }

        // Satellites resolve their slots only after every visible card has reached its final frame pose,
        // so the blue squares never disappear behind hero/support cards and always occupy free screen-space.
        updateOrbitalSquares(dt,carouselMotionActive);
        applyOrbitalSquareHover(dt);
        updateHeroNdcBounds();
        for(const card of activeCards) updateNumberLabel(card);
        scene.userData.activeLogicalCard=heroCard?.userData.sequenceNumber||1;
        scene.userData.activeSequenceStep=heroCard?.userData.sequenceStep||0;
        scene.userData.sequenceDirection=sequenceDirection;
        scene.userData.heroFlipped=heroFlipTarget>Math.PI*.5;
        scene.userData.visibleActiveCount=activeCards.filter(c=>c.visible && (c.userData.presence??0)>.08).length;
        scene.userData.supportSettleActive=!inputActive;
        publishSceneState();
        composer.render();
      }

      // Initial visible logical group is exactly 1,2,3,4,5 with hero 1.
      // VISUAL SCROLL remains original V33/Pass 4 and can travel any distance.
      // LOGICAL SEQUENCE changes only once after a complete stop: next hero = current hero +/- 1.
      // The completed gesture may change only the visible group size (1..7); it never changes how many logical cards are advanced.
      ensureAssignments(0);
      animate();
    }

    init();
    addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);composer.setSize(innerWidth,innerHeight)});
