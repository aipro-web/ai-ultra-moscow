# QA — V35.10.4.1.1 AUTO FLOW ON PATH

Base: V35.10.4.1 Unified Hero Gradient.

Change scope:
- Dense 2160-card spiral starts moving immediately on page load.
- Motion follows the original Pass 4 closed curve (same T direction as wheel-down scrolling).
- Card planes remain face-on; no self rotation.
- Glass and hero-gradient rail layers share the same instance matrices.
- Pre-sampled 4096-point path avoids per-frame Catmull-Rom evaluation for every card.

Protected behavior:
- Observer block: byte-identical to V35.10.4.1.
- Funnel commit block: byte-identical to V35.10.4.1.
- Mouse grab pointerdown block: byte-identical to V35.10.4.1.
- `targetT -= self.deltaY * SENSITIVITY`: preserved.

Checks:
- JS module `node --check`: PASS.
- assets/card-1.jpg … card-5.jpg: PRESENT.
- ZIP integrity: checked during packaging.
