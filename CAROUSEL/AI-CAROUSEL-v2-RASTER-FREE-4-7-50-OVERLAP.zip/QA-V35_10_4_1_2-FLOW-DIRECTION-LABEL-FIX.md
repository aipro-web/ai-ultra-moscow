# QA — V35.10.4.1.2

Base: V35.10.4.1.1, itself built from V35.10.4.1.

Changes only:
- ambient background path direction reversed;
- minimum active foreground count raised to 4, maximum remains 7;
- visible sequence badges no longer disappear merely because their anchor overlaps the hero.

Protected scroll / funnel / click-to-promote / grab logic otherwise unchanged.
