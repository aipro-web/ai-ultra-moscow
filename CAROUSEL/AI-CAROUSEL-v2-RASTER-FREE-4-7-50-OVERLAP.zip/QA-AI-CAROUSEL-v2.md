# AI Carousel v2 QA

- Base: AI Carousel v1.
- Raster: removed from runtime and package; no TextureLoader, no rasterMaterials, no assets folder.
- Active cards: procedural glass only.
- Background spiral: unchanged in size/geometry/material behavior from v1.
- Visible active cards: 4..7.
- Hero: remains centered.
- Every fully settled scroll regenerates a randomized support-card layout.
- Random layouts select separated viewport sites and add restrained jitter to reduce strong overlaps.
- During active scroll, support cards still follow the original path/lane behavior.
- Observer scroll core is intended to remain unchanged from v1.
