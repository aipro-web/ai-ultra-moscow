# AI Carousel v1 QA

Baseline: V35.10.4.1.3 Hero Hover 15px.

Change: after full scroll stop, visible support cards ease into six deterministic screen-space slots around the centered hero. During scrolling, all cards continue their original path motion.

Preserved:
- background/spiral flow untouched;
- 4..7 active-card limit;
- funnel/ring numbering;
- Observer scroll behavior;
- click/grab/flip;
- hero hover to ~15 px viewport margin.
