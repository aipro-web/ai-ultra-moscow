# V35.10.4.1.3 Hero Hover 15px

- Base: V35.10.4.1.2.
- Dense background/spiral cards are untouched.
- Hero now participates in hover growth.
- Hero hover is uniform/proportional and clamps to ~15 px viewport margin.
- Support hover behavior remains the previous 80% hero-size target.
- Scroll / funnel / ring-wrap / click / grab logic intentionally unchanged.
