QA FIX

Root cause of black screen: V35.10 ZIP omitted the assets/ directory while index.html still awaited five raster textures during boot. The loader caught the missing files, showed «Не удалось загрузить тестовые растровые карточки.» and returned before scene initialization.

Superseded: all raster card assets were removed from this build; index.html renders procedural glass only.
