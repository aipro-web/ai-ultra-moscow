# V35.10.4.1 — Unified Hero Gradient QA

Base: `V35.10.4-RING-WRAP-SEQUENCE`.

Visual-only change:
- Every active foreground card uses the exact same `bloomEdgeHeroMaterial` as the hero card.
- The old weaker support-card edge material is aliased to the hero material.
- All 2160 background flow cards receive an instanced left/right LED rail layer using the same hero gradient values:
  - warm `vec3(1.22, .91, .48)`
  - hot `vec3(1.75, 1.58, 1.28)`
  - intensity `1.24`
  - same corner boost curve.
- Background rails use one extra InstancedMesh draw call rather than per-card objects.

Protected behavior:
- Observer scroll block unchanged from V35.10.4.
- `SENSITIVITY`, `targetT -= self.deltaY*SENSITIVITY`, `setCamT(targetT)` unchanged.
- funnel stop / ring-wrap / grab / click / flip logic unchanged.
