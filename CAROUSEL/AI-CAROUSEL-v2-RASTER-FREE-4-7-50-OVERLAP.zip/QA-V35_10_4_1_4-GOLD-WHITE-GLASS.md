# V35.10.4.1.4 — Gold/White LED + Clean Glass

Visual-only update.

- Active-card left/right LED edges: gold → champagne → warm white gradient.
- All 2160 background-flow rails use the same gradient language.
- Bloom tuned for a cleaner premium LED glow instead of a flat yellow line.
- Active foreground cards now use Three.js physical transmission glass with light roughness/thickness for subtle optical blur while preserving readability.
- Background-flow glass was simplified to a smooth transparent neutral/champagne tint with no noisy/photo-like procedural ripple.
- Movement, path, scroll, funnel, ring-wrap, drag, hover and card sequencing were not changed.
