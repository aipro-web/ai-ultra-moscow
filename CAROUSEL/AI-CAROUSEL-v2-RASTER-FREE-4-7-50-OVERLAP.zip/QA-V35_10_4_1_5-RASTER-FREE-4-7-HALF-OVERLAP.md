# QA — Raster-free 4–7 / 50% overlap

- Raster assets: 0 (`png`, `jpg/jpeg`, `webp`, `gif`, `bmp`, `avif`).
- Embedded raster data URLs: 0.
- Foreground physical slots: 7 maximum.
- Visible foreground group: clamped to 4–7 cards.
- Settled overlap: 50% horizontal coverage between neighboring visible cards.
- Background flow: remains decorative and background-sized; focus-zone fade prevents it from reading as extra foreground cards.
- Foreground support cards: fixed readable support size; no tiny micro-tail cards.
- JavaScript module syntax: `node --check` passed.
