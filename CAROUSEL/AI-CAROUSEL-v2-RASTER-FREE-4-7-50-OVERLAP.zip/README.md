# AI Carousel v2

Raster-free active carousel built from AI Carousel v1.

Changes in v2:
- removed all raster card loading/rendering and raster assets;
- background spiral remains untouched;
- active hero remains centered;
- after each completed scroll, visible support cards settle into a new randomized, collision-aware composition;
- active count stays between 4 and 7;
- existing scroll, funnel, ring-wrap, hover, grab and flip behavior is preserved.
